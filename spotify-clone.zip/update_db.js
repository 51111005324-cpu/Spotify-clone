const fs = require('fs');

const dbFile = './backend/database.js';
let content = fs.readFileSync(dbFile, 'utf8');

const newSongs = JSON.parse(fs.readFileSync('./new_songs.json', 'utf8'));

// 1. Replace initialSongs
const initialSongsStr = 'const initialSongs = [\n' + newSongs.map(s => {
  return `  { id: ${s.id}, title: ${JSON.stringify(s.title)}, artist: ${JSON.stringify(s.artist)}, album: ${JSON.stringify(s.album)}, duration: ${s.duration}, genre: '${s.genre}', cover: '${s.cover}', audioUrl: '${s.audioUrl}', plays: ${s.plays} }`;
}).join(',\n') + '\n];';

content = content.replace(/const initialSongs = \[[\s\S]*?\];/, initialSongsStr);

// 2. Add audioUrl to CREATE TABLE songs
content = content.replace(
  /cover TEXT,/,
  'cover TEXT,\n      audioUrl TEXT,'
);

// 3. Add audioUrl to INSERT INTO songs
content = content.replace(
  /'INSERT INTO songs \(id, title, artist, album, duration, genre, cover, plays\) VALUES \(\?, \?, \?, \?, \?, \?, \?, \?\)',/,
  "'INSERT INTO songs (id, title, artist, album, duration, genre, cover, audioUrl, plays) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',"
);
content = content.replace(
  /\[s\.id, s\.title, s\.artist, s\.album, s\.duration, s\.genre, s\.cover, s\.plays\]/,
  "[s.id, s.title, s.artist, s.album, s.duration, s.genre, s.cover, s.audioUrl, s.plays]"
);

fs.writeFileSync(dbFile, content, 'utf8');
console.log('database.js updated');

// Delete existing db so it reseeds
try { fs.unlinkSync('./backend/database.sqlite'); console.log('database.sqlite deleted'); } catch (e) {}

