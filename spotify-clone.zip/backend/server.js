require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const { initDB } = require('./database');
const multer = require('multer');
const mm = require('music-metadata');
const fs = require('fs');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');

const JWT_SECRET = process.env.JWT_SECRET || 'spotify_clone_secret_fallback';

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../frontend')));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, path.join(__dirname, 'uploads')),
  filename: (req, file, cb) => cb(null, Date.now() + '-' + file.originalname.replace(/\s+/g, '_'))
});
const upload = multer({ storage });

let db;

// ─── HELPERS ──────────────────────────────────────────────────────────────────

/** JWT auth middleware — attaches req.userId or falls back to demo user */
function authenticateToken(req, res, next) {
  const auth = req.headers.authorization || '';
  const token = auth.replace('Bearer ', '');
  if (!token) { req.userId = 1; return next(); }

  // Support legacy fake-jwt tokens (for backward compat during transition)
  if (token.startsWith('fake-jwt-')) {
    const parts = token.split('-');
    req.userId = parseInt(parts[2]) || 1;
    return next();
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.userId = decoded.userId;
    next();
  } catch (e) {
    req.userId = 1;
    next();
  }
}

/** Convenience wrapper for routes that need userId */
async function getUserIdFromToken(req) {
  return req.userId || 1;
}

// ─── AUTH ROUTES ──────────────────────────────────────────────────────────────

app.post('/api/auth/login', async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password)
    return res.status(400).json({ error: 'Username and password are required' });

  try {
    const user = await db.get('SELECT * FROM users WHERE username = ?', [username]);
    if (!user) return res.status(401).json({ error: 'Invalid credentials' });

    // Support both bcrypt hashes and legacy plaintext passwords
    let valid = false;
    if (user.password.startsWith('$2')) {
      valid = await bcrypt.compare(password, user.password);
    } else {
      valid = user.password === password;
    }
    if (!valid) return res.status(401).json({ error: 'Invalid credentials' });

    const token = jwt.sign({ userId: user.id, username: user.username }, JWT_SECRET, { expiresIn: '7d' });
    const { password: _, ...safeUser } = user;
    res.json({ token, user: safeUser });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Database error' });
  }
});

app.post('/api/auth/register', async (req, res) => {
  const { username, email, password, name } = req.body;
  if (!username || !password || !name)
    return res.status(400).json({ error: 'Name, username and password are required' });

  try {
    const existing = await db.get('SELECT id FROM users WHERE username = ?', [username]);
    if (existing) return res.status(409).json({ error: 'Username already taken' });

    const hashedPassword = await bcrypt.hash(password, 12);
    const result = await db.run(
      'INSERT INTO users (username, email, password, name) VALUES (?, ?, ?, ?)',
      [username, email || '', hashedPassword, name]
    );

    const newUser = await db.get('SELECT * FROM users WHERE id = ?', [result.lastID]);
    const token = jwt.sign({ userId: newUser.id, username: newUser.username }, JWT_SECRET, { expiresIn: '7d' });
    const { password: _, ...safeUser } = newUser;
    res.json({ token, user: safeUser });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Database error' });
  }
});

// ─── SONGS ROUTES ─────────────────────────────────────────────────────────────

app.post('/api/songs/upload', upload.single('song'), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded' });

  try {
    const filePath = req.file.path;
    const metadata = await mm.parseFile(filePath);
    
    let title = metadata.common.title || req.file.originalname.replace('.mp3', '');
    let artist = metadata.common.artist || 'Unknown Artist';
    let album = metadata.common.album || 'Unknown Album';
    let duration = Math.floor(metadata.format.duration || 0);
    
    let coverUrl = 'https://picsum.photos/seed/song/300/300';
    
    if (metadata.common.picture && metadata.common.picture.length > 0) {
      const picture = metadata.common.picture[0];
      const ext = picture.format.split('/')[1] || 'jpeg';
      const coverFileName = `cover-${Date.now()}.${ext}`;
      const coverPath = path.join(__dirname, 'uploads', 'covers', coverFileName);
      fs.writeFileSync(coverPath, picture.data);
      coverUrl = `/uploads/covers/${coverFileName}`;
    }

    const audioUrl = `/uploads/${req.file.filename}`;
    
    const result = await db.run(
      'INSERT INTO songs (title, artist, album, duration, genre, cover, audioUrl, plays) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
      [title, artist, album, duration, 'Uploaded', coverUrl, audioUrl, 0]
    );

    const newSong = await db.get('SELECT * FROM songs WHERE id = ?', [result.lastID]);
    res.json(newSong);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error processing audio file' });
  }
});

app.get('/api/songs', async (req, res) => {
  const { q, genre } = req.query;
  try {
    let query = 'SELECT * FROM songs WHERE 1=1';
    let params = [];

    if (q) {
      query += ' AND (LOWER(title) LIKE ? OR LOWER(artist) LIKE ? OR LOWER(album) LIKE ?)';
      const search = `%${q.toLowerCase()}%`;
      params.push(search, search, search);
    }
    if (genre) {
      query += ' AND genre = ?';
      params.push(genre);
    }

    const songs = await db.all(query, params);
    res.json(songs);
  } catch (err) {
    res.status(500).json({ error: 'Database error' });
  }
});

app.get('/api/songs/trending', async (req, res) => {
  try {
    const trending = await db.all('SELECT * FROM songs ORDER BY plays DESC LIMIT 8');
    res.json(trending);
  } catch (err) {
    res.status(500).json({ error: 'Database error' });
  }
});

app.get('/api/songs/genres', async (req, res) => {
  try {
    const genres = await db.all('SELECT DISTINCT genre FROM songs ORDER BY genre');
    res.json(genres.map(g => g.genre));
  } catch (err) {
    res.status(500).json({ error: 'Database error' });
  }
});

app.get('/api/songs/:id', async (req, res) => {
  try {
    const song = await db.get('SELECT * FROM songs WHERE id = ?', [req.params.id]);
    if (!song) return res.status(404).json({ error: 'Song not found' });
    res.json(song);
  } catch (err) {
    res.status(500).json({ error: 'Database error' });
  }
});

// ─── PLAYLISTS ROUTES ─────────────────────────────────────────────────────────

app.get('/api/playlists', async (req, res) => {
  try {
    const playlists = await db.all('SELECT * FROM playlists');
    res.json(playlists);
  } catch (err) {
    res.status(500).json({ error: 'Database error' });
  }
});

app.get('/api/playlists/:id', async (req, res) => {
  try {
    const playlist = await db.get('SELECT * FROM playlists WHERE id = ?', [req.params.id]);
    if (!playlist) return res.status(404).json({ error: 'Playlist not found' });

    const songs = await db.all(`
      SELECT s.* FROM songs s
      JOIN playlist_songs ps ON s.id = ps.songId
      WHERE ps.playlistId = ?
    `, [playlist.id]);

    res.json({ ...playlist, songs });
  } catch (err) {
    res.status(500).json({ error: 'Database error' });
  }
});

app.post('/api/playlists', async (req, res) => {
  const { name, description } = req.body;
  if (!name) return res.status(400).json({ error: 'Playlist name is required' });

  try {
    const cover = `https://picsum.photos/seed/pl${Date.now()}/300/300`;
    const result = await db.run(
      'INSERT INTO playlists (name, description, cover, owner) VALUES (?, ?, ?, ?)',
      [name, description || '', cover, 'You']
    );

    const newPlaylist = await db.get('SELECT * FROM playlists WHERE id = ?', [result.lastID]);
    newPlaylist.songs = [];
    res.json(newPlaylist);
  } catch (err) {
    res.status(500).json({ error: 'Database error' });
  }
});

app.put('/api/playlists/:id', async (req, res) => {
  const { name, description } = req.body;
  try {
    const playlist = await db.get('SELECT id FROM playlists WHERE id = ?', [req.params.id]);
    if (!playlist) return res.status(404).json({ error: 'Playlist not found' });

    await db.run(
      'UPDATE playlists SET name = COALESCE(?, name), description = COALESCE(?, description) WHERE id = ?',
      [name, description, req.params.id]
    );

    const updated = await db.get('SELECT * FROM playlists WHERE id = ?', [req.params.id]);
    res.json(updated);
  } catch (err) {
    res.status(500).json({ error: 'Database error' });
  }
});

app.delete('/api/playlists/:id', async (req, res) => {
  try {
    const result = await db.run('DELETE FROM playlists WHERE id = ?', [req.params.id]);
    if (result.changes === 0) return res.status(404).json({ error: 'Playlist not found' });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Database error' });
  }
});

app.post('/api/playlists/:id/songs', async (req, res) => {
  const playlistId = parseInt(req.params.id);
  const songId = parseInt(req.body.songId);

  try {
    const playlist = await db.get('SELECT id FROM playlists WHERE id = ?', [playlistId]);
    if (!playlist) return res.status(404).json({ error: 'Playlist not found' });

    const song = await db.get('SELECT id FROM songs WHERE id = ?', [songId]);
    if (!song) return res.status(404).json({ error: 'Song not found' });

    await db.run('INSERT OR IGNORE INTO playlist_songs (playlistId, songId) VALUES (?, ?)', [playlistId, songId]);

    const songs = await db.all(`
      SELECT s.* FROM songs s
      JOIN playlist_songs ps ON s.id = ps.songId
      WHERE ps.playlistId = ?
    `, [playlistId]);

    res.json({ ...playlist, songs });
  } catch (err) {
    res.status(500).json({ error: 'Database error' });
  }
});

app.delete('/api/playlists/:id/songs/:songId', async (req, res) => {
  const playlistId = parseInt(req.params.id);
  const songId = parseInt(req.params.songId);

  try {
    const playlist = await db.get('SELECT id FROM playlists WHERE id = ?', [playlistId]);
    if (!playlist) return res.status(404).json({ error: 'Playlist not found' });

    await db.run('DELETE FROM playlist_songs WHERE playlistId = ? AND songId = ?', [playlistId, songId]);

    const songs = await db.all(`
      SELECT s.* FROM songs s
      JOIN playlist_songs ps ON s.id = ps.songId
      WHERE ps.playlistId = ?
    `, [playlistId]);

    res.json({ ...playlist, songs });
  } catch (err) {
    res.status(500).json({ error: 'Database error' });
  }
});

// ─── ALBUMS ROUTES ────────────────────────────────────────────────────────────

app.get('/api/albums', async (req, res) => {
  try {
    const albums = await db.all('SELECT * FROM albums');
    res.json(albums);
  } catch (err) {
    res.status(500).json({ error: 'Database error' });
  }
});

app.get('/api/albums/:id', async (req, res) => {
  try {
    const album = await db.get('SELECT * FROM albums WHERE id = ?', [req.params.id]);
    if (!album) return res.status(404).json({ error: 'Album not found' });

    const songs = await db.all(`
      SELECT s.* FROM songs s
      JOIN album_songs asongs ON s.id = asongs.songId
      WHERE asongs.albumId = ?
    `, [album.id]);

    res.json({ ...album, songs });
  } catch (err) {
    res.status(500).json({ error: 'Database error' });
  }
});

// ─── ARTISTS ROUTES ───────────────────────────────────────────────────────────

app.get('/api/artists', async (req, res) => {
  try {
    const artists = await db.all('SELECT * FROM artists');
    res.json(artists);
  } catch (err) {
    res.status(500).json({ error: 'Database error' });
  }
});

app.get('/api/artists/:id', async (req, res) => {
  try {
    const artist = await db.get('SELECT * FROM artists WHERE id = ?', [req.params.id]);
    if (!artist) return res.status(404).json({ error: 'Artist not found' });

    const songs = await db.all('SELECT * FROM songs WHERE artist = ?', [artist.name]);
    const albums = await db.all('SELECT * FROM albums WHERE artist = ?', [artist.name]);

    res.json({ ...artist, songs, albums });
  } catch (err) {
    res.status(500).json({ error: 'Database error' });
  }
});

// ─── SEARCH ROUTE ─────────────────────────────────────────────────────────────

app.get('/api/search', async (req, res) => {
  const q = (req.query.q || '').toLowerCase().trim();
  if (!q) return res.json({ songs: [], playlists: [], albums: [], artists: [] });

  const search = `%${q}%`;
  try {
    const [songs, playlists, albums, artists] = await Promise.all([
      db.all('SELECT * FROM songs WHERE LOWER(title) LIKE ? OR LOWER(artist) LIKE ? OR LOWER(album) LIKE ?', [search, search, search]),
      db.all('SELECT * FROM playlists WHERE LOWER(name) LIKE ?', [search]),
      db.all('SELECT * FROM albums WHERE LOWER(name) LIKE ? OR LOWER(artist) LIKE ?', [search, search]),
      db.all('SELECT * FROM artists WHERE LOWER(name) LIKE ?', [search])
    ]);

    res.json({ songs, playlists, albums, artists });
  } catch (err) {
    res.status(500).json({ error: 'Database error' });
  }
});

// ─── LIKED SONGS ROUTES ───────────────────────────────────────────────────────

app.get('/api/user/liked', authenticateToken, async (req, res) => {
  const userId = await getUserIdFromToken(req);
  try {
    const likedSongs = await db.all(`
      SELECT s.* FROM songs s
      JOIN user_liked_songs uls ON s.id = uls.songId
      WHERE uls.userId = ?
    `, [userId]);
    res.json(likedSongs);
  } catch (err) {
    res.status(500).json({ error: 'Database error' });
  }
});

app.post('/api/user/liked/:songId', authenticateToken, async (req, res) => {
  const userId = await getUserIdFromToken(req);
  const songId = parseInt(req.params.songId);

  try {
    const song = await db.get('SELECT id FROM songs WHERE id = ?', [songId]);
    if (!song) return res.status(404).json({ error: 'Song not found' });

    const existing = await db.get('SELECT * FROM user_liked_songs WHERE userId = ? AND songId = ?', [userId, songId]);
    
    let liked = false;
    if (existing) {
      await db.run('DELETE FROM user_liked_songs WHERE userId = ? AND songId = ?', [userId, songId]);
    } else {
      await db.run('INSERT INTO user_liked_songs (userId, songId) VALUES (?, ?)', [userId, songId]);
      liked = true;
    }

    const likedSongsList = await db.all('SELECT songId FROM user_liked_songs WHERE userId = ?', [userId]);
    res.json({ liked, likedSongs: likedSongsList.map(l => l.songId) });
  } catch (err) {
    res.status(500).json({ error: 'Database error' });
  }
});

// ─── USER PROFILE ─────────────────────────────────────────────────────────────

app.get('/api/user/profile', authenticateToken, async (req, res) => {
  const userId = await getUserIdFromToken(req);
  try {
    const user = await db.get('SELECT id, username, name, email, createdAt FROM users WHERE id = ?', [userId]);
    res.json(user);
  } catch (err) {
    res.status(500).json({ error: 'Database error' });
  }
});

// ─── SERVE FRONTEND ───────────────────────────────────────────────────────────

app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

// ─── START ────────────────────────────────────────────────────────────────────

initDB().then(database => {
  db = database;
  app.listen(PORT, () => {
    console.log(`\n🎵  Spotify Clone running at http://localhost:${PORT}`);
    console.log(`🗄️   Connected to SQLite database`);
    console.log('   Demo account → username: demo | password: demo123\n');
  });
}).catch(err => {
  console.error('Failed to initialize database:', err);
  process.exit(1);
});
