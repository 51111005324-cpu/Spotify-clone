const fs = require('fs');
const https = require('https');

const queries = [
  { term: 'Arijit Singh', limit: 30, genre: 'Bollywood' },
  { term: 'Kishore Kumar', limit: 20, genre: 'Old Bollywood' },
  { term: 'Lata Mangeshkar', limit: 15, genre: 'Old Bollywood' },
  { term: 'Mohammed Rafi', limit: 15, genre: 'Old Bollywood' },
  { term: 'Mukesh', limit: 10, genre: 'Old Bollywood' },
];

async function fetchSongs(queryObj) {
  return new Promise((resolve) => {
    const url = `https://itunes.apple.com/search?term=${encodeURIComponent(queryObj.term)}&media=music&limit=${queryObj.limit}`;
    https.get(url, res => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          const results = JSON.parse(data).results;
          const songs = results.map(r => ({
            title: r.trackName,
            artist: r.artistName,
            album: r.collectionName || 'Single',
            duration: Math.floor((r.trackTimeMillis || 0) / 1000),
            genre: queryObj.genre,
            cover: r.artworkUrl100 ? r.artworkUrl100.replace('100x100', '300x300') : 'https://picsum.photos/seed/song/300/300',
            audioUrl: r.previewUrl,
            plays: Math.floor(Math.random() * 5000000) + 1000000
          })).filter(s => s.audioUrl && s.duration > 0);
          resolve(songs);
        } catch (e) {
          console.error(e);
          resolve([]);
        }
      });
    }).on('error', () => resolve([]));
  });
}

async function main() {
  let allNewSongs = [];
  for (const q of queries) {
    console.log(`Fetching ${q.term}...`);
    const songs = await fetchSongs(q);
    allNewSongs = allNewSongs.concat(songs);
  }

  // Deduplicate by title to avoid weird repeats
  const seen = new Set();
  const uniqueSongs = [];
  for (const s of allNewSongs) {
    if (!seen.has(s.title)) {
      seen.add(s.title);
      uniqueSongs.push(s);
    }
  }

  // Read existing database.js
  const dbFile = './backend/database.js';
  let content = fs.readFileSync(dbFile, 'utf8');

  // Extract existing songs
  const match = content.match(/const initialSongs = \[([\s\S]*?)\];/);
  if (!match) throw new Error("Could not find initialSongs");
  
  // We'll just construct a new array by combining existing ones and new ones.
  // Wait, let's parse the existing ones. Actually, it's a JS file. Let's just append to the string.
  
  // Find highest ID in existing string
  let maxId = 0;
  const idMatches = match[1].match(/id:\s*(\d+)/g);
  if (idMatches) {
    for (const m of idMatches) {
      const id = parseInt(m.replace('id:', '').trim());
      if (id > maxId) maxId = id;
    }
  }

  const newSongsStrs = uniqueSongs.map(s => {
    maxId++;
    return `  { id: ${maxId}, title: ${JSON.stringify(s.title)}, artist: ${JSON.stringify(s.artist)}, album: ${JSON.stringify(s.album)}, duration: ${s.duration}, genre: '${s.genre}', cover: '${s.cover}', audioUrl: '${s.audioUrl}', plays: ${s.plays} }`;
  });

  const existingContent = match[1].trim();
  const appendedStr = `const initialSongs = [\n  ${existingContent},\n${newSongsStrs.join(',\n')}\n];`;

  content = content.replace(/const initialSongs = \[[\s\S]*?\];/, appendedStr);

  fs.writeFileSync(dbFile, content, 'utf8');
  console.log(`database.js updated with ${uniqueSongs.length} new songs`);

  // Delete existing db so it reseeds
  try { fs.unlinkSync('./backend/database.sqlite'); console.log('database.sqlite deleted'); } catch (e) {}
}

main();
