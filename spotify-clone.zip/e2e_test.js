const puppeteer = require('puppeteer');

const delay = ms => new Promise(res => setTimeout(res, ms));

(async () => {
  const browser = await puppeteer.launch({ args: ['--no-sandbox', '--disable-setuid-sandbox'] });
  const page = await browser.newPage();
  
  page.on('console', msg => console.log('PAGE LOG:', msg.text()));
  page.on('pageerror', err => console.error('PAGE ERROR:', err.message));
  
  await page.goto('http://localhost:3000');
  console.log('Page loaded');
  await delay(2000);
  
  // Login first?
  console.log('Checking if logged in');
  await page.evaluate(() => {
    const userInput = document.getElementById('username');
    if(userInput && userInput.offsetParent !== null) {
      console.log('Logging in...');
      userInput.value = 'demo';
      document.getElementById('password').value = 'demo123';
      document.querySelector('button[onclick="login()"]').click();
    }
  });
  await delay(1000);
  
  // Go to library to create a playlist
  console.log('Navigating to Library');
  await page.evaluate(() => navigate('library'));
  await delay(1000);

  // Create a playlist
  page.once('dialog', async dialog => {
    console.log('Dialog:', dialog.message());
    await dialog.accept('Test E2E Playlist');
  });
  
  console.log('Clicking New Playlist');
  await page.evaluate(() => document.querySelector('button[onclick="createPlaylist()"]').click());
  
  await delay(2000);
  
  // Go back to home to see songs
  console.log('Clicking Home');
  await page.evaluate(() => navigate('home'));
  
  await delay(1000);
  
  // Add first song to playlist
  console.log('Opening Add to Playlist Modal');
  await page.evaluate(() => {
    const btn = document.querySelector('button[title="Add to Playlist"]');
    if(btn) btn.click();
    else console.log('Add to playlist button NOT FOUND');
  });
  
  await delay(1000);
  
  console.log('Clicking Playlist in Modal');
  await page.evaluate(() => {
    const pl = document.querySelector('#modalPlaylistList div');
    if(pl) pl.click();
    else console.log('No playlist found in modal');
  });
  
  await delay(1000);
  
  console.log('Done testing. Exiting.');
  await browser.close();
})();
