---
name: fullstack-web-builder
description: >
  A complete skill for building full-stack web applications with a Node.js + Express
  backend and a modern HTML/CSS/JavaScript frontend. Use this skill whenever the user
  wants to build a web app, website clone, music app, e-commerce site, social media
  app, dashboard, portfolio, or any project that needs both a backend API and a
  frontend UI. Trigger this skill even if the user only asks for "frontend" or
  "backend" separately — both parts work best together. Also trigger for requests
  like "build me an app like X", "create a clone of Y", "I need a website for Z",
  or "make a full-stack project for college".
---

# Full-Stack Web Builder Skill

This skill produces production-quality, college-ready full-stack web projects using:
- **Backend**: Node.js + Express.js (REST API, in-memory or JSON data)
- **Frontend**: HTML5 + CSS3 + Vanilla JavaScript (no frameworks needed)

---

## STEP 1 — Understand the Project

Before writing any code, answer these from context or ask the user:

1. **What is the app?** (e.g., music player, e-commerce, blog, todo app)
2. **What data does it manage?** (users, products, posts, songs, orders…)
3. **Who are the users?** (students, customers, general public)
4. **Key features needed?** (login, search, CRUD, real-time, likes…)
5. **Any real data / APIs needed?** (or is mock data fine for college)

> For college projects: mock in-memory data is always fine. Say so to reassure the user.

---

## STEP 2 — Plan the Architecture

Always use this structure:

```
project-name/
├── backend/
│   ├── server.js        ← Express server + all API routes
│   └── package.json     ← dependencies
└── frontend/
    ├── index.html       ← full page structure
    ├── style.css        ← all styling
    └── app.js           ← all JS logic + API calls
```

**Design the API first** — list all routes before coding:

| Method | Route | What it does |
|--------|-------|-------------|
| POST | /api/auth/login | Login |
| POST | /api/auth/register | Register |
| GET | /api/[resource] | List all |
| GET | /api/[resource]/:id | Get one |
| POST | /api/[resource] | Create |
| PUT | /api/[resource]/:id | Update |
| DELETE | /api/[resource]/:id | Delete |
| GET | /api/search?q= | Search |

---

## STEP 3 — Backend Rules (server.js)

### Always include these at the top:
```js
const express = require('express');
const cors = require('cors');
const path = require('path');
const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../frontend')));
```

### Data Design Pattern:
```js
// Use arrays for mock data — no database needed for college projects
const items = [
  { id: 1, name: "Example", field: "value", createdAt: new Date() },
];

// Always include: id, all display fields, timestamps if relevant
```

### Auth Pattern (simple, no real JWT):
```js
const users = [
  { id: 1, username: "demo", password: "demo123", name: "Demo User" }
];

app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body;
  const user = users.find(u => u.username === username && u.password === password);
  if (!user) return res.status(401).json({ error: 'Invalid credentials' });
  const { password: _, ...safeUser } = user; // never send password
  res.json({ token: `token-${user.id}`, user: safeUser });
});
```

### CRUD Pattern:
```js
// GET all
app.get('/api/items', (req, res) => {
  const { q } = req.query;
  let result = items;
  if (q) result = items.filter(i => i.name.toLowerCase().includes(q.toLowerCase()));
  res.json(result);
});

// GET one
app.get('/api/items/:id', (req, res) => {
  const item = items.find(i => i.id === parseInt(req.params.id));
  if (!item) return res.status(404).json({ error: 'Not found' });
  res.json(item);
});

// POST create
app.post('/api/items', (req, res) => {
  const newItem = { id: items.length + 1, ...req.body, createdAt: new Date() };
  items.push(newItem);
  res.json(newItem);
});

// PUT update
app.put('/api/items/:id', (req, res) => {
  const idx = items.findIndex(i => i.id === parseInt(req.params.id));
  if (idx === -1) return res.status(404).json({ error: 'Not found' });
  items[idx] = { ...items[idx], ...req.body };
  res.json(items[idx]);
});

// DELETE
app.delete('/api/items/:id', (req, res) => {
  const idx = items.findIndex(i => i.id === parseInt(req.params.id));
  if (idx === -1) return res.status(404).json({ error: 'Not found' });
  items.splice(idx, 1);
  res.json({ success: true });
});
```

### Always end server.js with:
```js
// Serve frontend for all other routes
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

app.listen(PORT, () => {
  console.log(`\n🚀 App running at http://localhost:${PORT}\n`);
});
```

### package.json template:
```json
{
  "name": "project-name",
  "version": "1.0.0",
  "scripts": {
    "start": "node server.js",
    "dev": "nodemon server.js"
  },
  "dependencies": {
    "cors": "^2.8.5",
    "express": "^4.18.2"
  },
  "devDependencies": {
    "nodemon": "^3.0.1"
  }
}
```

---

## STEP 4 — Frontend Rules

### index.html structure:
```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>App Name</title>
  <!-- Google Fonts — always use Outfit or DM Sans or Poppins -->
  <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;600;700;800&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="style.css" />
</head>
<body>
  <!-- Auth screens (login/register) -->
  <!-- App shell (shown after login) -->
  <!-- Toast/notification container -->
  <script src="app.js"></script>
</body>
</html>
```

### CSS Design Rules:
1. **Always use CSS variables** for colors, spacing, fonts:
```css
:root {
  --bg: #121212;
  --bg2: #1e1e1e;
  --accent: #your-color;
  --text: #ffffff;
  --text-secondary: #aaaaaa;
  --radius: 10px;
  --transition: 0.2s cubic-bezier(0.4, 0, 0.2, 1);
}
```
2. **Theme choices** by app type:
   - Music app → dark (#121212) + green (#1ed760)
   - E-commerce → white/light + blue or orange
   - Social media → white + purple/pink
   - Dashboard → dark + blue/cyan
   - Food app → white + warm red/orange
   - Education → light + indigo/blue

3. **Always add hover effects** on interactive elements
4. **Always add transitions** on buttons and cards
5. **Use flexbox/grid** for layout — no floats

### app.js structure:
```js
// 1. Config
const API = window.location.origin + '/api';

// 2. State object — single source of truth
let state = {
  user: null, token: null,
  data: [],          // main resource list
  currentItem: null, // currently selected/viewed
};

// 3. API helper — always wrap fetch
async function api(path, opts = {}) {
  try {
    const res = await fetch(API + path, {
      headers: {
        'Content-Type': 'application/json',
        ...(state.token ? { Authorization: `Bearer ${state.token}` } : {})
      },
      ...opts,
    });
    if (!res.ok) throw await res.json();
    return res.json();
  } catch(e) {
    if (e.error) throw e;
    throw { error: 'Cannot connect to server. Run npm start first.' };
  }
}

// 4. Toast notification
function showToast(msg, icon = '✓') { /* always include */ }

// 5. Auth functions (login, register, logout, saveSession)

// 6. Init function — load all data after login
async function initApp() { /* fetch data, render UI */ }

// 7. Navigation — show/hide views
function navigate(view, id) { /* switch active views */ }

// 8. Data loading functions (one per view/section)
// 9. Render helpers (card, row, list item)
// 10. Event handlers (forms, buttons, search)
// 11. Utility functions (formatDate, formatPrice, etc.)
// 12. Keyboard shortcuts (always add Space/Enter support)
// 13. DOMContentLoaded — check localStorage for saved session
```

---

## STEP 5 — UX Must-Haves (always include)

### Toast Notifications:
```js
function showToast(message, icon = '✓') {
  const el = document.createElement('div');
  el.className = 'toast';
  el.innerHTML = `<span>${icon}</span> ${message}`;
  document.getElementById('toastContainer').appendChild(el);
  setTimeout(() => { el.classList.add('hide'); setTimeout(() => el.remove(), 300); }, 2500);
}
```

### Session Persistence (localStorage):
```js
// After login
localStorage.setItem('app_token', token);
localStorage.setItem('app_user', JSON.stringify(user));

// On page load
const token = localStorage.getItem('app_token');
if (token) { state.token = token; initApp(); }

// On logout
localStorage.removeItem('app_token');
localStorage.removeItem('app_user');
```

### Enter key on forms:
```js
document.getElementById('passwordInput').addEventListener('keydown', e => {
  if (e.key === 'Enter') login();
});
```

### Loading state on buttons:
```js
btn.textContent = 'Loading...'; btn.disabled = true;
try { /* API call */ } finally { btn.textContent = 'Original'; btn.disabled = false; }
```

### Search with debounce:
```js
let searchTimer;
function debounceSearch(val) {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(() => performSearch(val), 300);
}
```

---

## STEP 6 — Setup Instructions (always give these)

Always end the project with these setup steps:

```bash
# 1. Install dependencies
cd backend
npm install

# 2. Start the server
npm start
# → App running at http://localhost:3000

# 3. Open browser
# Go to: http://localhost:3000
# DO NOT open index.html directly as a file
```

**Common error fixes to always mention:**

| Error | Fix |
|-------|-----|
| `EADDRINUSE port 3000` | Run: `kill -9 $(lsof -t -i:3000)` |
| `Cannot connect to server` | Make sure `npm start` is running |
| `ENOENT index.html` | Check folder structure — frontend/ must contain index.html |
| Login not working | Open `http://localhost:3000` not the file directly |

---

## STEP 7 — Quality Checklist

Before delivering code, verify:
- [ ] All API routes have error handling (404, 400, 401)
- [ ] No password sent in API responses
- [ ] Frontend uses `window.location.origin + '/api'` not hardcoded localhost
- [ ] All forms have Enter-key support
- [ ] All buttons have loading states
- [ ] CSS has hover effects on all clickable elements
- [ ] localStorage used for session persistence
- [ ] Mobile responsive (at least basic media queries)
- [ ] Setup instructions included
- [ ] Demo credentials documented

---

## Common App Templates

### Music / Streaming App
- Resources: songs, playlists, albums, artists
- Features: player, queue, shuffle, repeat, like, search
- Theme: dark + green

### E-Commerce Shop
- Resources: products, categories, cart, orders, users
- Features: product list, cart, checkout, order history
- Theme: light + brand color

### Social Media / Blog
- Resources: posts, users, comments, likes, follows
- Features: feed, create post, profile, search
- Theme: white + blue/purple

### Restaurant / Food App
- Resources: menu items, categories, orders, tables
- Features: menu browse, add to cart, order tracking
- Theme: warm white + red/orange

### College Management
- Resources: students, courses, grades, attendance
- Features: login by role (admin/student/teacher), reports
- Theme: light + indigo

### Todo / Project Manager
- Resources: tasks, projects, labels, users
- Features: create/edit/delete tasks, filters, drag-drop
- Theme: light + blue

---

## Notes for College Projects

- **No database needed** — in-memory arrays are fine for demos
- **No real JWT** — simple token strings work for demos
- **No real payments** — simulate order confirmation
- **No real emails** — just show success messages
- **Data resets on restart** — mention this and suggest MongoDB as upgrade path
- **Always include a demo account** (username: demo, password: demo123)
