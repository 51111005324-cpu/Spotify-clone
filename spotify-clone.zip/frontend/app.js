/* ─── Config ─────────────────────────────────────────── */
const API = window.location.origin + '/api';

/* ─── State ──────────────────────────────────────────── */
let state = {
  user: null, token: null,
  songs: [], playlists: [], albums: [], likedSongs: [],
  queue: [], queueIndex: -1,
  isPlaying: false, shuffle: false, repeat: false,
  currentSong: null, searchTimer: null,
};

/* ─── API Helper ──────────────────────────────────────── */
async function api(path, opts = {}) {
  try {
    const res = await fetch(API + path, {
      headers: { 'Content-Type': 'application/json', ...(state.token ? { Authorization: `Bearer ${state.token}` } : {}) },
      ...opts,
    });
    if (!res.ok) throw await res.json();
    return res.json();
  } catch (e) {
    if (e.error) throw e;
    throw { error: 'Cannot connect to server. Make sure npm start is running at http://localhost:3000' };
  }
}

/* ─── Toast ───────────────────────────────────────────── */
function showToast(message, icon = '✓') {
  const container = document.getElementById('toastContainer');
  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.innerHTML = `<span class="toast-icon">${icon}</span><span>${message}</span>`;
  container.appendChild(toast);
  setTimeout(() => {
    toast.classList.add('hide');
    setTimeout(() => toast.remove(), 300);
  }, 2500);
}

/* ─── Auth ────────────────────────────────────────────── */
async function login() {
  const username = document.getElementById('loginUsername').value.trim();
  const password = document.getElementById('loginPassword').value;
  const errEl = document.getElementById('loginError');
  const btn = document.querySelector('#loginScreen .btn-primary');
  errEl.classList.add('hidden');
  if (!username || !password) { errEl.textContent = 'Please enter username and password'; errEl.classList.remove('hidden'); return; }
  btn.textContent = 'Logging in…'; btn.disabled = true;
  try {
    const data = await api('/auth/login', { method: 'POST', body: JSON.stringify({ username, password }) });
    saveSession(data); initApp();
  } catch (e) {
    errEl.textContent = e.error || 'Login failed';
    errEl.classList.remove('hidden');
  } finally { btn.textContent = 'Log In'; btn.disabled = false; }
}

async function register() {
  const name = document.getElementById('regName').value.trim();
  const username = document.getElementById('regUsername').value.trim();
  const email = document.getElementById('regEmail').value.trim();
  const password = document.getElementById('regPassword').value;
  const errEl = document.getElementById('registerError');
  const btn = document.querySelector('#registerScreen .btn-primary');
  errEl.classList.add('hidden');
  if (!name || !username || !email || !password) { errEl.textContent = 'Please fill in all fields'; errEl.classList.remove('hidden'); return; }
  btn.textContent = 'Creating…'; btn.disabled = true;
  try {
    const data = await api('/auth/register', { method: 'POST', body: JSON.stringify({ name, username, email, password }) });
    saveSession(data); initApp();
  } catch (e) {
    errEl.textContent = e.error || 'Registration failed';
    errEl.classList.remove('hidden');
  } finally { btn.textContent = 'Sign Up'; btn.disabled = false; }
}

function saveSession({ token, user }) {
  state.token = token; state.user = user;
  localStorage.setItem('spotify_token', token);
  localStorage.setItem('spotify_user', JSON.stringify(user));
}

function logout() {
  state = { ...state, user: null, token: null, currentSong: null, isPlaying: false };
  localStorage.removeItem('spotify_token');
  localStorage.removeItem('spotify_user');
  document.getElementById('app').classList.add('hidden');
  showLogin();
}

function showLogin() { document.getElementById('registerScreen').classList.add('hidden'); document.getElementById('loginScreen').classList.remove('hidden'); }
function showRegister() { document.getElementById('loginScreen').classList.add('hidden'); document.getElementById('registerScreen').classList.remove('hidden'); }

document.addEventListener('DOMContentLoaded', () => {
  ['loginPassword','loginUsername'].forEach(id => {
    document.getElementById(id)?.addEventListener('keydown', e => { if (e.key === 'Enter') login(); });
  });
});

/* ─── App Init ────────────────────────────────────────── */
async function initApp() {
  document.getElementById('loginScreen').classList.add('hidden');
  document.getElementById('registerScreen').classList.add('hidden');
  document.getElementById('app').classList.remove('hidden');
  document.getElementById('userName').textContent = state.user.name;
  document.getElementById('userAvatar').textContent = state.user.name[0].toUpperCase();
  try {
    const [songs, playlists, albums, liked] = await Promise.all([
      api('/songs'), api('/playlists'), api('/albums'), api('/user/liked')
    ]);
    state.songs = songs; state.playlists = playlists; state.albums = albums;
    state.likedSongs = liked.map(s => s.id);
    renderSidebar(); navigate('home'); initPlayer();
  } catch (e) { console.error('Load error:', e); }
}

window.addEventListener('DOMContentLoaded', () => {
  const token = localStorage.getItem('spotify_token');
  const user = localStorage.getItem('spotify_user');
  if (token && user) { state.token = token; state.user = JSON.parse(user); initApp(); }
});

/* ─── Navigation ──────────────────────────────────────── */
function navigate(view, id = null) {
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  document.querySelectorAll('.mobile-nav-item').forEach(n => n.classList.remove('active'));
  
  const wrap = document.getElementById('searchBarWrap');
  wrap.style.display = view === 'search' ? 'block' : 'none';

  const views = { home: 'homeView', search: 'searchView', library: 'libraryView', playlist: 'playlistView', album: 'albumView', user: 'userView' };
  if (views[view]) document.getElementById(views[view]).classList.add('active');

  const navMap = { home: "navigate('home')", search: "navigate('search')", library: "navigate('library')" };
  if (navMap[view]) {
    const navEl = document.querySelector(`.sidebar-nav [onclick="${navMap[view]}"]`);
    if (navEl) navEl.classList.add('active');
    const mobileNavEl = document.querySelector(`.mobile-nav [onclick="${navMap[view]}"]`);
    if (mobileNavEl) mobileNavEl.classList.add('active');
  }

  if (view === 'home') loadHome();
  else if (view === 'search') { loadSearch(); setTimeout(() => document.getElementById('searchInput').focus(), 100); }
  else if (view === 'library') loadLibrary();
  else if (view === 'playlist') loadPlaylist(id);
  else if (view === 'album') loadAlbum(id);
  else if (view === 'user') loadUser();
}

/* ─── Recently Played ─────────────────────────────────── */
function getRecentlyPlayed() {
  try { return JSON.parse(localStorage.getItem('spotify_recent') || '[]'); } catch { return []; }
}
function addToRecentlyPlayed(song) {
  let recent = getRecentlyPlayed().filter(s => s.id !== song.id);
  recent.unshift({ id: song.id, title: song.title, artist: song.artist, cover: song.cover });
  if (recent.length > 8) recent = recent.slice(0, 8);
  localStorage.setItem('spotify_recent', JSON.stringify(recent));
}
function renderRecentlyPlayed() {
  const recent = getRecentlyPlayed();
  const section = document.getElementById('recentSection');
  const strip = document.getElementById('recentlyPlayedStrip');
  if (!recent.length) { section.style.display = 'none'; return; }
  section.style.display = 'block';
  strip.innerHTML = recent.map(s => `
    <div class="recent-chip" onclick="playSong(${s.id})">
      <img src="${s.cover}" alt="${s.title}" />
      <div>
        <div style="font-size:12px;font-weight:600">${s.title}</div>
        <div style="font-size:11px;color:var(--text-secondary)">${s.artist}</div>
      </div>
    </div>`).join('');
}

/* ─── Home ────────────────────────────────────────────── */
async function loadHome() {
  const hour = new Date().getHours();
  const greeting = hour < 12 ? '☀️ Good morning' : hour < 17 ? '👋 Good afternoon' : '🌙 Good evening';
  document.getElementById('greetingText').textContent = greeting;

  renderRecentlyPlayed();

  const trending = await api('/songs/trending');
  document.getElementById('trendingGrid').innerHTML = trending.map(s => songCard(s)).join('');

  document.getElementById('featuredPlaylists').innerHTML = state.playlists.slice(0, 6).map(p => playlistCard(p)).join('');

  const bollywood = state.songs.filter(s => s.genre === 'Bollywood').slice(0, 6);
  document.getElementById('bollywoodGrid').innerHTML = bollywood.map(s => songCard(s)).join('');

  document.getElementById('albumsGrid').innerHTML = state.albums.slice(0, 6).map(a => albumCard(a)).join('');
}

/* ─── Dynamic Gradient ────────────────────────────────── */
const gradientColors = [
  '#1a3a2a','#2a1a3a','#3a1a1a','#1a2a3a',
  '#2a3a1a','#3a2a1a','#1a3a3a','#3a1a2a'
];
let colorIndex = 0;
function updateDynamicGradient() {
  colorIndex = (colorIndex + 1) % gradientColors.length;
  const color = gradientColors[colorIndex];
  document.querySelector('.gradient-header')?.style &&
    (document.querySelector('.gradient-header').style.background = `linear-gradient(to bottom, ${color}88, transparent)`);
  document.querySelectorAll('.playlist-header').forEach(h => {
    h.style.background = `linear-gradient(to bottom, ${color}66, transparent)`;
  });
}

/* ─── Search ──────────────────────────────────────────── */
function loadSearch() {
  const input = document.getElementById('searchInput');
  if (!input.value) renderBrowse(); else performSearch(input.value);
}

function debounceSearch(val) {
  clearTimeout(state.searchTimer);
  updateSearchSuggestions(val);
  state.searchTimer = setTimeout(() => {
    if (val.trim()) performSearch(val); else renderBrowse();
  }, 300);
}

function updateSearchSuggestions(val) {
  const box = document.getElementById('searchSuggestions');
  if (!val.trim()) { box.classList.add('hidden'); return; }
  const matches = state.songs
    .filter(s => s.title.toLowerCase().includes(val.toLowerCase()) || s.artist.toLowerCase().includes(val.toLowerCase()))
    .slice(0, 5);
  if (!matches.length) { box.classList.add('hidden'); return; }
  box.classList.remove('hidden');
  box.innerHTML = matches.map(s => `
    <div class="suggestion-item" onmousedown="playSong(${s.id}); document.getElementById('searchInput').value='${s.title.replace(/'/g,"\\'")}'; hideSuggestions();">
      <svg viewBox="0 0 24 24" fill="currentColor" width="14" height="14"><path d="M12 3v10.55c-.59-.34-1.27-.55-2-.55-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4V7h4V3h-6z"/></svg>
      <div>
        <div style="font-size:13px;font-weight:500">${s.title}</div>
        <div style="font-size:11px;color:var(--text-secondary)">${s.artist}</div>
      </div>
    </div>`).join('');
}

function showSuggestions() {
  const val = document.getElementById('searchInput').value;
  if (val.trim()) updateSearchSuggestions(val);
}
function hideSuggestions() { document.getElementById('searchSuggestions').classList.add('hidden'); }

async function performSearch(q) {
  const results = await api(`/search?q=${encodeURIComponent(q)}`);
  const container = document.getElementById('searchResults');
  let html = '';
  if (results.songs.length) {
    html += `<div class="section-header"><h2>Songs</h2></div>`;
    html += `<div class="song-table-header"><span>#</span><span>TITLE</span><span>ALBUM</span><span>⏱</span><span></span></div>`;
    html += results.songs.map((s, i) => songRow(s, i + 1)).join('');
  }
  if (results.playlists.length) {
    html += `<div class="section-header" style="margin-top:24px"><h2>Playlists</h2></div><div class="grid-4">${results.playlists.map(p => playlistCard(p)).join('')}</div>`;
  }
  if (results.albums.length) {
    html += `<div class="section-header" style="margin-top:24px"><h2>Albums</h2></div><div class="grid-4">${results.albums.map(a => albumCard(a)).join('')}</div>`;
  }
  if (!html) html = `<div class="empty-state">No results for "<strong>${q}</strong>"</div>`;
  container.innerHTML = html;
}

function renderBrowse() {
  const genres = [
    {label:'Pop',       color:'#1e3264'}, {label:'Bollywood', color:'#e8115b'},
    {label:'Hip-Hop',   color:'#8d67ab'}, {label:'R&B',       color:'#ba5d07'},
    {label:'K-Pop',     color:'#148a08'}, {label:'Indie Pop', color:'#0d73ec'},
    {label:'Funk',      color:'#e91429'}, {label:'English Pop',color:'#1e3264'},
  ];
  document.getElementById('searchResults').innerHTML = `
    <div class="section-header"><h2>Browse all</h2></div>
    <div class="browse-grid">
      ${genres.map(g => `<div class="browse-card" style="background:${g.color}" onclick="searchGenre('${g.label}')"><div class="browse-card-title">${g.label}</div></div>`).join('')}
    </div>`;
}

async function searchGenre(genre) {
  document.getElementById('searchInput').value = genre;
  const songs = await api(`/songs?genre=${encodeURIComponent(genre)}`);
  const container = document.getElementById('searchResults');
  let html = `<div class="section-header"><h2>${genre}</h2></div>`;
  if (songs.length) {
    html += `<div class="song-table-header"><span>#</span><span>TITLE</span><span>ALBUM</span><span>⏱</span><span></span></div>`;
    html += songs.map((s, i) => songRow(s, i + 1)).join('');
  } else {
    html += `<div class="empty-state">No songs in this genre yet.</div>`;
  }
  container.innerHTML = html;
}

/* ─── Library ─────────────────────────────────────────── */
async function loadLibrary() {
  const liked = await api('/user/liked');
  state.likedSongs = liked.map(s => s.id);
  document.getElementById('likedCount').textContent = liked.length;
  const likedList = document.getElementById('likedSongsList');
  if (liked.length) {
    likedList.innerHTML = `<div class="song-table-header"><span>#</span><span>TITLE</span><span>ALBUM</span><span>⏱</span><span></span></div>`;
    likedList.innerHTML += liked.map((s, i) => songRow(s, i + 1)).join('');
  } else {
    likedList.innerHTML = `<div class="empty-state">No liked songs yet. Tap ♥ on any song to save it here.</div>`;
  }
  const userPlaylists = state.playlists.filter(p => p.owner === 'You');
  document.getElementById('userPlaylists').innerHTML = userPlaylists.map(p => playlistCard(p)).join('');

  const uploads = state.songs.filter(s => s.genre === 'Uploaded');
  const uploadsList = document.getElementById('userUploadsList');
  if (uploadsList) {
    if (uploads.length) {
      uploadsList.innerHTML = `<div class="song-table-header"><span>#</span><span>TITLE</span><span>ALBUM</span><span>⏱</span><span></span></div>`;
      uploadsList.innerHTML += uploads.map((s, i) => songRow(s, i + 1)).join('');
    } else {
      uploadsList.innerHTML = `<div class="empty-state">No songs uploaded yet. Click + Upload MP3 to add your own full-length music!</div>`;
    }
  }
}

/* ─── Playlist / Album ────────────────────────────────── */
async function loadPlaylist(id) {
  const pl = await api(`/playlists/${id}`);
  const isOwner = pl.owner === 'You';
  
  let actionsHtml = `<button class="play-all-btn" onclick="playAll(${JSON.stringify(pl.songs).replace(/"/g,'&quot;')})">▶ Play All</button>`;
  if (isOwner) {
    actionsHtml += `<button class="btn-sm btn-outline" style="margin-left:12px; border-color:#e74c3c; color:#e74c3c;" onclick="deletePlaylist(${pl.id})">Delete Playlist</button>`;
  }

  document.getElementById('playlistHeader').innerHTML = `
    <img class="playlist-cover" src="${pl.cover}" alt="${pl.name}" />
    <div class="playlist-meta">
      <div class="playlist-type">Playlist</div>
      <div class="playlist-name">${pl.name}</div>
      <div class="playlist-desc">${pl.description}</div>
      <div class="playlist-stats">${pl.owner} • ${pl.songs.length} songs</div>
      <div class="playlist-actions">${actionsHtml}</div>
    </div>`;
    
  const body = document.getElementById('playlistSongs');
  body.innerHTML = `<div class="song-table-header"><span>#</span><span>TITLE</span><span>ALBUM</span><span>⏱</span><span></span></div>`;
  body.innerHTML += pl.songs.map((s, i) => songRow(s, i + 1, isOwner ? pl.id : null)).join('');
}

async function loadAlbum(id) {
  const alb = await api(`/albums/${id}`);
  document.getElementById('albumHeader').innerHTML = `
    <img class="playlist-cover" src="${alb.cover}" alt="${alb.name}" />
    <div class="playlist-meta">
      <div class="playlist-type">Album</div>
      <div class="playlist-name">${alb.name}</div>
      <div class="playlist-desc">${alb.artist}</div>
      <div class="playlist-stats">${alb.year} • ${alb.songs.length} songs</div>
      <div class="playlist-actions">
        <button class="play-all-btn" onclick="playAll(${JSON.stringify(alb.songs).replace(/"/g,'&quot;')})">▶ Play All</button>
      </div>
    </div>`;
  const body = document.getElementById('albumSongs');
  body.innerHTML = `<div class="song-table-header"><span>#</span><span>TITLE</span><span>ALBUM</span><span>⏱</span><span></span></div>`;
  body.innerHTML += alb.songs.map((s, i) => songRow(s, i + 1)).join('');
}

/* ─── User Profile ──────────────────────────────────────── */
async function loadUser() {
  const profile = await api('/user/profile');
  
  document.getElementById('userHeader').innerHTML = `
    <div class="user-avatar" style="width:180px;height:180px;font-size:72px;box-shadow:0 20px 60px rgba(0,0,0,0.7);flex-shrink:0;">${profile.name[0].toUpperCase()}</div>
    <div class="playlist-meta">
      <div class="playlist-type">Profile</div>
      <div class="playlist-name" style="font-size:56px">${profile.name}</div>
      <div class="playlist-desc">${state.playlists.filter(p => p.owner === 'You').length} Public Playlists</div>
      <div class="playlist-stats">Joined ${new Date(profile.createdAt).toLocaleDateString()}</div>
    </div>`;

  const liked = await api('/user/liked');
  
  document.getElementById('userProfilePlaylists').innerHTML = state.playlists.filter(p => p.owner === 'You').map(p => playlistCard(p)).join('');
  
  const likedContainer = document.getElementById('userProfileLiked');
  if (liked.length) {
    likedContainer.innerHTML = `<div class="song-table-header"><span>#</span><span>TITLE</span><span>ALBUM</span><span>⏱</span><span></span></div>`;
    likedContainer.innerHTML += liked.slice(0, 10).map((s, i) => songRow(s, i + 1)).join('');
  } else {
    likedContainer.innerHTML = `<div class="empty-state">No liked songs yet.</div>`;
  }
}

/* ─── Sidebar ─────────────────────────────────────────── */
function renderSidebar() {
  document.getElementById('sidebarPlaylists').innerHTML = state.playlists.map(p =>
    `<div class="sidebar-playlist-item" onclick="navigate('playlist', ${p.id})">${p.name}</div>`
  ).join('');
}

/* ─── Upload ──────────────────────────────────────────── */
async function uploadSong(input) {
  if (!input.files || !input.files[0]) return;
  const file = input.files[0];
  if (!file.type.includes('audio')) {
    showToast('Please select a valid audio file', '❌');
    return;
  }
  
  showToast('Uploading and parsing song...', '⏳');
  
  const formData = new FormData();
  formData.append('song', file);
  
  try {
    const res = await fetch('http://localhost:3000/api/songs/upload', {
      method: 'POST',
      body: formData // No Content-Type header for FormData!
    });
    
    if (!res.ok) throw new Error('Upload failed');
    const newSong = await res.json();
    
    // Add to state
    state.songs.push(newSong);
    
    showToast(`Successfully uploaded ${newSong.title}!`, '✅');
    
    // Refresh library view if active
    if (document.getElementById('libraryView').classList.contains('active')) {
      loadLibrary();
    }
  } catch (e) {
    console.error(e);
    showToast('Failed to upload song', '❌');
  } finally {
    input.value = ''; // reset
  }
}

/* ─── Card / Row Renderers ────────────────────────────── */
function songCard(s) {
  return `<div class="card" onclick="playSong(${s.id})">
    <div class="card-cover-wrap">
      <img class="card-cover" src="${s.cover}" alt="${s.title}" loading="lazy" />
      <div class="card-play-btn"><svg viewBox="0 0 24 24" fill="currentColor" width="22" height="22"><path d="M8 5v14l11-7z"/></svg></div>
    </div>
    <div class="card-title">${s.title}</div>
    <div class="card-sub">${s.artist}</div>
  </div>`;
}
function playlistCard(p) {
  return `<div class="card" onclick="navigate('playlist',${p.id})">
    <div class="card-cover-wrap">
      <img class="card-cover" src="${p.cover}" alt="${p.name}" loading="lazy" />
      <div class="card-play-btn"><svg viewBox="0 0 24 24" fill="currentColor" width="22" height="22"><path d="M8 5v14l11-7z"/></svg></div>
    </div>
    <div class="card-title">${p.name}</div>
    <div class="card-sub">${p.description || p.owner}</div>
  </div>`;
}
function albumCard(a) {
  return `<div class="card" onclick="navigate('album',${a.id})">
    <div class="card-cover-wrap">
      <img class="card-cover" src="${a.cover}" alt="${a.name}" loading="lazy" />
      <div class="card-play-btn"><svg viewBox="0 0 24 24" fill="currentColor" width="22" height="22"><path d="M8 5v14l11-7z"/></svg></div>
    </div>
    <div class="card-title">${a.name}</div>
    <div class="card-sub">${a.artist} • ${a.year}</div>
  </div>`;
}

function songRow(s, num, playlistId = null) {
  const liked = state.likedSongs.includes(s.id);
  const isPlaying = state.currentSong?.id === s.id;
  const numContent = isPlaying
    ? `<div class="now-playing-bars ${state.isPlaying ? '' : 'paused'}"><span></span><span></span><span></span></div>`
    : num;
    
  let removeBtnHtml = '';
  if (playlistId) {
    removeBtnHtml = `
      <button class="song-like" onclick="event.stopPropagation(); removeFromPlaylist(${playlistId}, ${s.id})" title="Remove from Playlist" style="margin-right: 8px;">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="15" height="15"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
      </button>
    `;
  }

  return `<div class="song-row ${isPlaying ? 'playing' : ''}" id="row-${s.id}" ondblclick="playSong(${s.id})">
    <div class="song-num" id="num-${s.id}">${numContent}</div>
    <div class="song-info">
      <img class="song-thumb" src="${s.cover}" alt="${s.title}" loading="lazy" />
      <div class="song-meta">
        <div class="song-name">${s.title}</div>
        <div class="song-artist">${s.artist}</div>
      </div>
    </div>
    <div class="song-album">${s.album}</div>
    <div class="song-duration">${formatDuration(s.duration)}</div>
    <div style="display:flex; align-items:center;">
      <button class="song-like" onclick="event.stopPropagation(); showAddToPlaylistModal(${s.id})" title="Add to Playlist" style="margin-right: 8px;">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="15" height="15"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
      </button>
      ${removeBtnHtml}
      <button class="song-like ${liked ? 'liked' : ''}" onclick="event.stopPropagation(); toggleLikeSong(${s.id}, this)">
        <svg viewBox="0 0 24 24" fill="${liked ? 'currentColor' : 'none'}" stroke="currentColor" stroke-width="2" width="15" height="15"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>
      </button>
    </div>
  </div>`;
}

/* ─── Player ──────────────────────────────────────────── */
const audio = document.getElementById('audioPlayer');

function initPlayer() {
  audio.addEventListener('timeupdate', () => { if (audio.duration) updateProgressUI(audio.currentTime, audio.duration); });
  audio.addEventListener('ended', onSongEnd);
  audio.volume = 0.8;
}

function playSong(id) {
  const song = state.songs.find(s => s.id === id);
  if (!song) return;
  
  let idx = state.queue.findIndex(s => s.id === id);
  if (idx !== -1) {
    state.queueIndex = idx;
  } else {
    state.queue = state.songs;
    state.queueIndex = state.songs.findIndex(s => s.id === id);
  }
  loadSong(song);
}

function playAll(songs) {
  if (!songs?.length) return;
  state.queue = songs; state.queueIndex = 0;
  loadSong(songs[0]);
}

function loadSong(song) {
  state.currentSong = song;
  audio.src = '';

  // Update player UI
  document.getElementById('playerTitle').textContent = song.title;
  document.getElementById('playerArtist').textContent = song.artist;
  document.getElementById('playerCover').src = song.cover;
  
  document.getElementById('epTitle').textContent = song.title;
  document.getElementById('epArtist').textContent = song.artist;
  document.getElementById('epCover').src = song.cover;
  
  document.title = `${song.title} – ${song.artist} | Spotify`;

  // Like state
  const liked = state.likedSongs.includes(song.id);
  const likeBtn = document.getElementById('playerLikeBtn');
  likeBtn.classList.toggle('liked', liked);
  likeBtn.querySelector('svg').setAttribute('fill', liked ? 'currentColor' : 'none');

  // Save to recently played
  addToRecentlyPlayed(song);

  // Update gradient
  updateDynamicGradient();

  // Highlight playing row
  document.querySelectorAll('.song-row').forEach(r => r.classList.remove('playing'));
  document.querySelectorAll('.now-playing-bars').forEach(b => b.replaceWith(b.closest('.song-num') ? document.createTextNode(b.closest('[id^=row-]')?.querySelector('.song-num')?.textContent || '') : b));

  const row = document.getElementById(`row-${song.id}`);
  if (row) {
    row.classList.add('playing');
    const numEl = document.getElementById(`num-${song.id}`);
    if (numEl) numEl.innerHTML = `<div class="now-playing-bars"><span></span><span></span><span></span></div>`;
  }

  // Play audio
  audio.src = song.audioUrl || 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3';
  audio.play().catch(e => console.error('Playback failed:', e));
  state.isPlaying = true;
  updatePlayPauseIcon();
  updateNowPlayingBars();

  // Reset lyrics if expanded player is open
  const lyricsBox = document.getElementById('epLyricsBox');
  if (lyricsBox) lyricsBox.classList.add('hidden');
  const lyricsBtn = document.getElementById('epLyricsBtn');
  if (lyricsBtn) lyricsBtn.classList.remove('active');
}

function updateProgressUI(current, total) {
  const pct = (current / total) * 100;
  
  const fill = document.getElementById('progressFill');
  const thumb = document.getElementById('progressThumb');
  if (fill) fill.style.width = pct + '%';
  if (thumb) thumb.style.left = pct + '%';
  
  const curEl = document.getElementById('currentTime');
  const totEl = document.getElementById('totalTime');
  if (curEl) curEl.textContent = formatDuration(Math.floor(current));
  if (totEl) totEl.textContent = formatDuration(total);

  const epFill = document.getElementById('epProgressFill');
  const epThumb = document.getElementById('epProgressThumb');
  if (epFill) epFill.style.width = pct + '%';
  if (epThumb) epThumb.style.left = pct + '%';
  
  const epCur = document.getElementById('epCurrentTime');
  const epTot = document.getElementById('epTotalTime');
  if (epCur) epCur.textContent = formatDuration(Math.floor(current));
  if (epTot) epTot.textContent = formatDuration(total);
}

function togglePlay() {
  if (!state.currentSong) return;
  state.isPlaying = !state.isPlaying;
  updatePlayPauseIcon();
  updateNowPlayingBars();
  if (state.isPlaying) {
    audio.play();
  } else {
    audio.pause();
  }
}

function updatePlayPauseIcon() {
  document.getElementById('playIcon').style.display = state.isPlaying ? 'none' : 'block';
  document.getElementById('pauseIcon').style.display = state.isPlaying ? 'block' : 'none';
  
  document.getElementById('epPlayIcon').style.display = state.isPlaying ? 'none' : 'block';
  document.getElementById('epPauseIcon').style.display = state.isPlaying ? 'block' : 'none';
  
  const epCover = document.getElementById('epCover');
  if (epCover) epCover.classList.toggle('playing', state.isPlaying);
}

function updateNowPlayingBars() {
  const bars = document.getElementById('nowPlayingBars');
  if (bars) bars.classList.toggle('paused', !state.isPlaying);
  document.querySelectorAll('.song-row.playing .now-playing-bars').forEach(b => {
    b.classList.toggle('paused', !state.isPlaying);
  });
}

function seek(e) {
  if (!state.currentSong || !audio.duration) return;
  const rect = e.currentTarget.getBoundingClientRect();
  const pct = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
  audio.currentTime = pct * audio.duration;
}

function nextSong() {
  if (!state.queue.length) return;
  if (state.shuffle) state.queueIndex = Math.floor(Math.random() * state.queue.length);
  else state.queueIndex = (state.queueIndex + 1) % state.queue.length;
  loadSong(state.queue[state.queueIndex]);
}

function prevSong() {
  if (!state.queue.length) return;
  state.queueIndex = (state.queueIndex - 1 + state.queue.length) % state.queue.length;
  loadSong(state.queue[state.queueIndex]);
}

function onSongEnd() {
  if (state.repeat) { audio.currentTime = 0; audio.play(); return; }
  nextSong();
}

function toggleShuffle() {
  state.shuffle = !state.shuffle;
  document.getElementById('shuffleBtn').classList.toggle('active', state.shuffle);
  document.getElementById('epShuffleBtn').classList.toggle('active', state.shuffle);
  showToast(state.shuffle ? 'Shuffle on' : 'Shuffle off', '🔀');
}

function toggleRepeat() {
  state.repeat = !state.repeat;
  document.getElementById('repeatBtn').classList.toggle('active', state.repeat);
  document.getElementById('epRepeatBtn').classList.toggle('active', state.repeat);
  showToast(state.repeat ? 'Repeat on' : 'Repeat off', '🔁');
}

function openExpandedPlayer() {
  if (!state.currentSong) return;
  document.getElementById('expandedPlayer').classList.remove('hidden');
}

function closeExpandedPlayer() {
  document.getElementById('expandedPlayer').classList.add('hidden');
}

/* ─── Lyrics View ─────────────────────────────────────── */
async function toggleLyrics() {
  const lyricsBox = document.getElementById('epLyricsBox');
  const btn = document.getElementById('epLyricsBtn');
  
  if (!lyricsBox.classList.contains('hidden')) {
    lyricsBox.classList.add('hidden');
    btn.classList.remove('active');
    return;
  }
  
  if (!state.currentSong) return;
  
  lyricsBox.classList.remove('hidden');
  btn.classList.add('active');
  lyricsBox.innerHTML = '<div style="margin-top:40%">Loading lyrics...<br><span style="font-size:14px;font-weight:400;color:var(--text-secondary)">via lyrics.ovh</span></div>';
  
  try {
    const title = state.currentSong.title.replace(/\(.*\)/g, '').trim(); // Remove things like (From "War")
    const artist = state.currentSong.artist.split(',')[0].split('&')[0].trim(); // Get first artist
    
    const res = await fetch(`https://api.lyrics.ovh/v1/${encodeURIComponent(artist)}/${encodeURIComponent(title)}`);
    if (!res.ok) throw new Error('Not found');
    
    const data = await res.json();
    if (data.lyrics) {
      // Remove any "Paroles de la chanson" prefixes
      let lyrics = data.lyrics.replace(/Paroles de la chanson.+?\n/g, '').trim();
      lyricsBox.textContent = lyrics;
    } else {
      throw new Error('No lyrics');
    }
  } catch (e) {
    lyricsBox.innerHTML = '<div style="margin-top:40%;color:var(--text-secondary)">Lyrics not found for this track.</div>';
  }
}

function setVolume(val) { audio.volume = val / 100; }

/* ─── Like ────────────────────────────────────────────── */
async function toggleLikeSong(id, btnEl) {
  // Animate immediately
  if (btnEl) { btnEl.classList.remove('pop'); void btnEl.offsetWidth; btnEl.classList.add('pop'); }

  const data = await api(`/user/liked/${id}`, { method: 'POST' });
  state.likedSongs = data.likedSongs;
  const isNowLiked = data.liked;

  showToast(isNowLiked ? 'Added to Liked Songs' : 'Removed from Liked Songs', isNowLiked ? '💚' : '🤍');

  // Update all like buttons for this song
  document.querySelectorAll('.song-like').forEach(btn => {
    const match = btn.getAttribute('onclick')?.match(/toggleLikeSong\((\d+)/);
    if (!match) return;
    const songId = parseInt(match[1]);
    const liked = state.likedSongs.includes(songId);
    btn.classList.toggle('liked', liked);
    btn.querySelector('svg').setAttribute('fill', liked ? 'currentColor' : 'none');
  });

  // Update player like btn
  if (state.currentSong?.id === id) {
    const likeBtn = document.getElementById('playerLikeBtn');
    likeBtn.classList.toggle('liked', isNowLiked);
    likeBtn.querySelector('svg').setAttribute('fill', isNowLiked ? 'currentColor' : 'none');
  }
}

async function toggleLike() {
  if (!state.currentSong) return;
  const likeBtn = document.getElementById('playerLikeBtn');
  likeBtn.classList.remove('pop'); void likeBtn.offsetWidth; likeBtn.classList.add('pop');
  toggleLikeSong(state.currentSong.id, null);
}

/* ─── Create Playlist ─────────────────────────────────── */
async function createPlaylist() {
  const name = prompt('Playlist name:');
  if (!name?.trim()) return;
  
  try {
    const pl = await api('/playlists', { method: 'POST', body: JSON.stringify({ name: name.trim() }) });
    state.playlists.push(pl);
    renderSidebar();
    
    // If library view is currently active, update the grid so the new playlist is visible immediately if they navigate back.
    if (document.getElementById('libraryView').classList.contains('active')) {
      loadLibrary();
    }
    
    showToast(`Playlist "${pl.name}" created`, '🎵');
    navigate('playlist', pl.id);
  } catch (err) {
    showToast(err.error || 'Failed to create playlist', '❌');
    console.error('Error creating playlist:', err);
  }
}

async function deletePlaylist(id) {
  if (!confirm('Are you sure you want to delete this playlist?')) return;
  try {
    await api(`/playlists/${id}`, { method: 'DELETE' });
    state.playlists = state.playlists.filter(p => p.id !== id);
    renderSidebar();
    if (document.getElementById('libraryView').classList.contains('active')) {
      loadLibrary();
    }
    showToast('Playlist deleted', '🗑️');
    navigate('library');
  } catch (err) {
    showToast('Failed to delete playlist', '❌');
    console.error(err);
  }
}

async function removeFromPlaylist(playlistId, songId) {
  if (!confirm('Remove this song from the playlist?')) return;
  try {
    await api(`/playlists/${playlistId}/songs/${songId}`, { method: 'DELETE' });
    showToast('Song removed', '✂️');
    loadPlaylist(playlistId); // Reload to reflect changes
  } catch (err) {
    showToast('Failed to remove song', '❌');
    console.error(err);
  }
}

let activeSongIdForPlaylist = null;
function showAddToPlaylistModal(songId) {
  activeSongIdForPlaylist = songId;
  const userPlaylists = state.playlists.filter(p => p.owner === 'You');
  const modalList = document.getElementById('modalPlaylistList');
  if (userPlaylists.length === 0) {
    modalList.innerHTML = `<div style="color:#b3b3b3;">You don't have any playlists yet.</div>`;
  } else {
    modalList.innerHTML = userPlaylists.map(p => `
      <div style="padding:12px; background:#333; border-radius:4px; cursor:pointer;" 
           onmouseover="this.style.background='#444'" 
           onmouseout="this.style.background='#333'"
           onclick="addToPlaylist(${p.id})">
        ${p.name}
      </div>
    `).join('');
  }
  document.getElementById('addToPlaylistModal').style.display = 'flex';
}

function closeAddToPlaylistModal() {
  document.getElementById('addToPlaylistModal').style.display = 'none';
  activeSongIdForPlaylist = null;
}

async function addToPlaylist(playlistId) {
  if (!activeSongIdForPlaylist) return;
  const songId = activeSongIdForPlaylist;
  try {
    await api(`/playlists/${playlistId}/songs`, { 
      method: 'POST', 
      body: JSON.stringify({ songId }) 
    });
    showToast('Added to playlist', '✅');
  } catch (err) {
    showToast('Failed to add song. It might already be in this playlist.', '❌');
    console.error(err);
  } finally {
    closeAddToPlaylistModal();
  }
}

/* ─── Utils ───────────────────────────────────────────── */
function formatDuration(sec) {
  const m = Math.floor(sec / 60);
  const s = String(Math.floor(sec % 60)).padStart(2, '0');
  return `${m}:${s}`;
}

// Keyboard shortcuts
document.addEventListener('keydown', e => {
  if (e.target.tagName === 'INPUT') return;
  if (e.code === 'Space')       { e.preventDefault(); togglePlay(); }
  if (e.code === 'ArrowRight')  nextSong();
  if (e.code === 'ArrowLeft')   prevSong();
  if (e.code === 'KeyL')        toggleLike();
  if (e.code === 'KeyS')        toggleShuffle();
});