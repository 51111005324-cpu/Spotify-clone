const fs = require('fs');
const https = require('https');

const queries = [
  { term: 'horror podcast', limit: 15, genre: 'Podcast' },
  { term: 'horror hindi podcast', limit: 15, genre: 'Podcast' }
];

async function fetchSongs(queryObj) {
  return new Promise((resolve) => {
    const url = `https://itunes.apple.com/search?term=${encodeURIComponent(queryObj.term)}&media=podcast&limit=${queryObj.limit}`;
    https.get(url, res => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          const results = JSON.parse(data).results;
          const songs = results.map(r => ({
            title: r.trackName || r.collectionName,
            artist: r.artistName,
            album: r.collectionName || 'Podcast',
            duration: Math.floor((r.trackTimeMillis || 300000) / 1000), // podcasts sometimes don't have trackTimeMillis
            genre: queryObj.genre,
            cover: r.artworkUrl600 ? r.artworkUrl600 : (r.artworkUrl100 ? r.artworkUrl100.replace('100x100', '600x600') : 'https://picsum.photos/seed/podcast/300/300'),
            audioUrl: r.previewUrl || r.feedUrl, // iTunes might not give previewUrl for podcasts directly in this endpoint? Wait, media=podcast gives feedUrl, trackViewUrl. Actually let's check what it gives. If no previewUrl, we'll try to find an alternative or just use a placeholder audio since we just need previews.
            plays: Math.floor(Math.random() * 500000) + 50000
          })).filter(s => s.audioUrl);
          
          resolve(songs);
        } catch (e) {
          console.error(e);
          resolve([]);
        }
      });
    }).on('error', () => resolve([]));
  });
}

async function main() {
  let allNewSongs = [];
  for (const q of queries) {
    console.log(`Fetching ${q.term}...`);
    // Wait, iTunes podcast search doesn't always return `previewUrl`.
    // Let's search with media=music term=horror podcast ? No, let's just query and see if previewUrl exists.
    // If not, we will fallback to a generic audio preview URL for demo purposes.
    const url = `https://itunes.apple.com/search?term=${encodeURIComponent(q.term)}&media=podcast&limit=${q.limit}`;
    const data = await new Promise(res => {
      https.get(url, r => {
        let d = '';
        r.on('data', c => d += c);
        r.on('end', () => res(JSON.parse(d).results));
      });
    });

    const parsed = data.map(r => ({
      title: r.trackName || r.collectionName,
      artist: r.artistName,
      album: r.collectionName || 'Podcast',
      duration: 180, // Default 3 mins if missing
      genre: q.genre,
      cover: r.artworkUrl600 || r.artworkUrl100 || 'https://picsum.photos/seed/podcast/300/300',
      // If previewUrl is missing for podcasts, use a generic scary sound from a free sound library or just fallback to another iTunes music preview.
      // iTunes actually sometimes has episode URLs if entity=podcastEpisode. Let's use entity=podcastEpisode for better audio previews!
      audioUrl: r.previewUrl || r.episodeUrl || 'https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview115/v4/12/35/38/12353846-5e58-6927-14e3-b1d61994e097/mzaf_10527447475358055416.plus.aac.p.m4a', // Fallback to a horror movie soundtrack preview
      plays: Math.floor(Math.random() * 500000) + 50000
    }));
    allNewSongs = allNewSongs.concat(parsed);
  }

  // Also fetch explicit podcast episodes to ensure we get audioUrls
  for (const q of queries) {
    const url = `https://itunes.apple.com/search?term=${encodeURIComponent(q.term)}&entity=podcastEpisode&limit=10`;
    const data = await new Promise(res => {
      https.get(url, r => {
        let d = '';
        r.on('data', c => d += c);
        r.on('end', () => res(JSON.parse(d).results));
      });
    });

    const parsed = data.map(r => ({
      title: r.trackName,
      artist: r.artistName || r.collectionName,
      album: r.collectionName || 'Podcast Episode',
      duration: Math.floor((r.trackTimeMillis || 300000) / 1000),
      genre: q.genre,
      cover: r.artworkUrl600 || r.artworkUrl100 || 'https://picsum.photos/seed/podcast/300/300',
      audioUrl: r.previewUrl || r.episodeUrl,
      plays: Math.floor(Math.random() * 500000) + 50000
    })).filter(s => s.audioUrl);
    
    allNewSongs = allNewSongs.concat(parsed);
  }

  const seen = new Set();
  const uniqueSongs = [];
  for (const s of allNewSongs) {
    if (!seen.has(s.title)) {
      seen.add(s.title);
      uniqueSongs.push(s);
    }
  }

  const dbFile = './backend/database.js';
  let content = fs.readFileSync(dbFile, 'utf8');
  const match = content.match(/const initialSongs = \[([\s\S]*?)\];/);
  let maxId = 0;
  const idMatches = match[1].match(/id:\s*(\d+)/g);
  if (idMatches) {
    for (const m of idMatches) {
      const id = parseInt(m.replace('id:', '').trim());
      if (id > maxId) maxId = id;
    }
  }

  const newSongsStrs = uniqueSongs.map(s => {
    maxId++;
    return `  { id: ${maxId}, title: ${JSON.stringify(s.title)}, artist: ${JSON.stringify(s.artist)}, album: ${JSON.stringify(s.album)}, duration: ${s.duration}, genre: '${s.genre}', cover: '${s.cover}', audioUrl: '${s.audioUrl}', plays: ${s.plays} }`;
  });

  const existingContent = match[1].trim();
  const appendedStr = `const initialSongs = [\n  ${existingContent},\n${newSongsStrs.join(',\n')}\n];`;
  content = content.replace(/const initialSongs = \[[\s\S]*?\];/, appendedStr);

  fs.writeFileSync(dbFile, content, 'utf8');
  console.log(`database.js updated with ${uniqueSongs.length} podcast episodes`);

  try { fs.unlinkSync('./backend/database.sqlite'); console.log('database.sqlite deleted'); } catch (e) {}
}

main();
