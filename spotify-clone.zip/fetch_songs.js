const fs = require('fs');
const https = require('https');

const queries = [
  'Blinding Lights The Weeknd',
  'Levitating Dua Lipa',
  'Stay Kid LAROI',
  'Montero Lil Nas X',
  'Good 4 U Olivia Rodrigo',
  'Peaches Justin Bieber',
  'drivers license Olivia Rodrigo',
  'Kiss Me More Doja Cat',
  'Butter BTS',
  'Permission to Dance BTS',
  'Bad Habits Ed Sheeran',
  'Heat Waves Glass Animals',
  'Industry Baby Lil Nas X',
  'Shivers Ed Sheeran',
  'Watermelon Sugar Harry Styles',
  'As It Was Harry Styles',
  // Bollywood songs
  'Tum Hi Ho Arijit Singh',
  'Channa Mereya Arijit Singh',
  'Kesariya Arijit Singh',
  'Desi Girl Priyanka',
  'Jai Ho A.R. Rahman',
  'Kala Chashma Badshah',
  'Ghungroo Arijit Singh',
  'Kabira Arijit Singh'
];

async function fetchSong(query, id) {
  return new Promise((resolve) => {
    const url = 'https://itunes.apple.com/search?term=' + encodeURIComponent(query) + '&media=music&limit=1';
    https.get(url, res => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          const results = JSON.parse(data).results;
          if (results.length > 0) {
            const r = results[0];
            const genre = id > 16 ? 'Bollywood' : r.primaryGenreName.includes('K-Pop') ? 'K-Pop' : r.primaryGenreName;
            resolve({
              id,
              title: r.trackName,
              artist: r.artistName,
              album: r.collectionName,
              duration: Math.floor(r.trackTimeMillis / 1000),
              genre,
              cover: r.artworkUrl100.replace('100x100', '300x300'),
              audioUrl: r.previewUrl,
              plays: Math.floor(Math.random() * 5000000) + 1000000
            });
          } else {
            resolve(null);
          }
        } catch (e) {
          resolve(null);
        }
      });
    }).on('error', () => resolve(null));
  });
}

async function main() {
  const songs = [];
  let id = 1;
  for (const q of queries) {
    const s = await fetchSong(q, id);
    if (s) {
      songs.push(s);
      id++;
    }
  }
  fs.writeFileSync('new_songs.json', JSON.stringify(songs, null, 2));
  console.log('Saved to new_songs.json');
}

main();
