/**
 * ═══════════════════════════════════════════════════
 *  SPOTIFY CLONE — Full End-to-End API Test Suite
 * ═══════════════════════════════════════════════════
 */

const BASE = 'http://localhost:3000';
const UNIQUE = Date.now();
let token = '';
let userId = null;
let playlistId = null;
let songId = null;
let albumId = null;
let artistId = null;

const results = { pass: 0, fail: 0, tests: [] };

// ── Utilities ──────────────────────────────────────

async function req(method, path, body, auth) {
  const headers = { 'Content-Type': 'application/json' };
  if (auth) headers['Authorization'] = `Bearer ${auth}`;
  const res = await fetch(`${BASE}${path}`, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined
  });
  let data;
  try { data = await res.json(); } catch { data = {}; }
  return { status: res.status, data };
}

function test(label, pass, detail = '') {
  const icon = pass ? '✅' : '❌';
  const status = pass ? 'PASS' : 'FAIL';
  console.log(`  ${icon} [${status}] ${label}${detail ? ' — ' + detail : ''}`);
  results.tests.push({ label, pass, detail });
  if (pass) results.pass++; else results.fail++;
}

function section(title) {
  console.log(`\n${'═'.repeat(55)}`);
  console.log(`  🎵  ${title}`);
  console.log(`${'─'.repeat(55)}`);
}

// ═══════════════════════════════════════════════════
//  1. HEALTH — Frontend served
// ═══════════════════════════════════════════════════
section('1. Frontend Served');

const htmlRes = await fetch(`${BASE}/`);
test('GET / returns 200 (frontend served)', htmlRes.status === 200, `status=${htmlRes.status}`);
const htmlText = await htmlRes.text();
test('HTML contains <title>', htmlText.includes('<title>'), 'page has a title tag');
test('HTML references app.js', htmlText.includes('app.js'), 'frontend JS loaded');

// ═══════════════════════════════════════════════════
//  2. AUTH — Register & Login
// ═══════════════════════════════════════════════════
section('2. Auth — Register & Login');

// Register new user
const regRes = await req('POST', '/api/auth/register', {
  name: `Test User ${UNIQUE}`,
  username: `testuser_${UNIQUE}`,
  email: `test_${UNIQUE}@example.com`,
  password: 'Password123!'
});
test('POST /api/auth/register → 200', regRes.status === 200, `status=${regRes.status}`);
test('Register returns JWT token', !!regRes.data.token, `token=${regRes.data.token?.slice(0,20)}...`);
test('Register returns user object', !!regRes.data.user?.username, `username=${regRes.data.user?.username}`);
test('Password not in response', !regRes.data.user?.password, 'password field omitted');
token = regRes.data.token || '';
userId = regRes.data.user?.id;

// Duplicate registration
const dupRes = await req('POST', '/api/auth/register', {
  name: 'Dup', username: `testuser_${UNIQUE}`, password: 'pass'
});
test('POST register duplicate → 409', dupRes.status === 409, `status=${dupRes.status}`);

// Login with correct creds
const loginRes = await req('POST', '/api/auth/login', {
  username: `testuser_${UNIQUE}`, password: 'Password123!'
});
test('POST /api/auth/login → 200', loginRes.status === 200, `status=${loginRes.status}`);
test('Login returns JWT token', !!loginRes.data.token, `token present`);
token = loginRes.data.token || token; // use login token from now

// Login with wrong password
const badLogin = await req('POST', '/api/auth/login', {
  username: `testuser_${UNIQUE}`, password: 'WRONG'
});
test('Login wrong password → 401', badLogin.status === 401, `status=${badLogin.status}`);

// Demo account login
const demoLogin = await req('POST', '/api/auth/login', { username: 'demo', password: 'demo123' });
test('Demo account login → 200', demoLogin.status === 200, `status=${demoLogin.status}`);

// ═══════════════════════════════════════════════════
//  3. USER PROFILE
// ═══════════════════════════════════════════════════
section('3. User Profile');

const profileRes = await req('GET', '/api/user/profile', null, token);
test('GET /api/user/profile → 200', profileRes.status === 200, `status=${profileRes.status}`);
test('Profile has username', !!profileRes.data.username, `username=${profileRes.data.username}`);
test('Profile has no password field', !profileRes.data.password, 'safe response');

// ═══════════════════════════════════════════════════
//  4. SONGS
// ═══════════════════════════════════════════════════
section('4. Songs');

const songsRes = await req('GET', '/api/songs');
test('GET /api/songs → 200', songsRes.status === 200, `status=${songsRes.status}`);
test('Songs returns array', Array.isArray(songsRes.data), `count=${songsRes.data.length}`);
test('Songs array is non-empty', songsRes.data.length > 0, `${songsRes.data.length} songs in DB`);

if (songsRes.data.length > 0) {
  const s = songsRes.data[0];
  songId = s.id;
  test('Song has required fields', !!(s.id && s.title && s.artist), `id=${s.id}, title="${s.title}"`);
}

// Get single song
const songRes = await req('GET', `/api/songs/${songId}`);
test(`GET /api/songs/${songId} → 200`, songRes.status === 200, `title="${songRes.data.title}"`);

const notFoundSong = await req('GET', '/api/songs/99999999');
test('GET /api/songs/99999999 → 404', notFoundSong.status === 404, `status=${notFoundSong.status}`);

// Trending
const trendingRes = await req('GET', '/api/songs/trending');
test('GET /api/songs/trending → 200', trendingRes.status === 200, `count=${trendingRes.data.length}`);
test('Trending returns ≤8 songs', trendingRes.data.length <= 8, `count=${trendingRes.data.length}`);

// Genres
const genresRes = await req('GET', '/api/songs/genres');
test('GET /api/songs/genres → 200', genresRes.status === 200, `genres=${genresRes.data.join(', ').slice(0,50)}`);
test('Genres returns array', Array.isArray(genresRes.data), `count=${genresRes.data.length}`);

// Search by song title
if (songsRes.data.length > 0) {
  const queryWord = songsRes.data[0].title.split(' ')[0];
  const searchSongs = await req('GET', `/api/songs?q=${encodeURIComponent(queryWord)}`);
  test(`GET /api/songs?q="${queryWord}" → 200`, searchSongs.status === 200, `hits=${searchSongs.data.length}`);
}

// Genre filter
if (genresRes.data.length > 0) {
  const g = genresRes.data[0];
  const genreFilter = await req('GET', `/api/songs?genre=${encodeURIComponent(g)}`);
  test(`GET /api/songs?genre="${g.slice(0,15)}" → 200`, genreFilter.status === 200, `hits=${genreFilter.data.length}`);
}

// ═══════════════════════════════════════════════════
//  5. LIKED SONGS
// ═══════════════════════════════════════════════════
section('5. Liked Songs');

const likedRes = await req('GET', '/api/user/liked', null, token);
test('GET /api/user/liked → 200', likedRes.status === 200, `status=${likedRes.status}`);
test('Liked songs returns array', Array.isArray(likedRes.data), `count=${likedRes.data.length}`);

// Like a song (toggle on)
const likeRes = await req('POST', `/api/user/liked/${songId}`, {}, token);
test(`POST /api/user/liked/${songId} → 200`, likeRes.status === 200, `liked=${likeRes.data.liked}`);
test('Like toggle returns liked=true', likeRes.data.liked === true, `liked=${likeRes.data.liked}`);
test('likedSongs array includes songId', likeRes.data.likedSongs?.includes(songId), `contains ${songId}`);

// Unlike (toggle off)
const unlikeRes = await req('POST', `/api/user/liked/${songId}`, {}, token);
test(`POST /api/user/liked/${songId} toggle off`, unlikeRes.data.liked === false, `liked=${unlikeRes.data.liked}`);

// Like a non-existent song
const likeBad = await req('POST', '/api/user/liked/99999999', {}, token);
test('Like non-existent song → 404', likeBad.status === 404, `status=${likeBad.status}`);

// ═══════════════════════════════════════════════════
//  6. PLAYLISTS
// ═══════════════════════════════════════════════════
section('6. Playlists');

// Get all playlists
const playlistsRes = await req('GET', '/api/playlists');
test('GET /api/playlists → 200', playlistsRes.status === 200, `count=${playlistsRes.data.length}`);
test('Playlists returns array', Array.isArray(playlistsRes.data), `count=${playlistsRes.data.length}`);

// Create playlist
const createPL = await req('POST', '/api/playlists', {
  name: `E2E Playlist ${UNIQUE}`,
  description: 'Created by automated test'
});
test('POST /api/playlists → 200', createPL.status === 200, `id=${createPL.data.id}`);
test('Playlist has name', createPL.data.name === `E2E Playlist ${UNIQUE}`, `name="${createPL.data.name}"`);
test('Playlist has cover image', !!createPL.data.cover, `cover=${createPL.data.cover?.slice(0,30)}`);
test('New playlist has empty songs', Array.isArray(createPL.data.songs) && createPL.data.songs.length === 0, 'songs=[]');
playlistId = createPL.data.id;

// Create without name → 400
const createBad = await req('POST', '/api/playlists', { description: 'no name' });
test('POST /api/playlists without name → 400', createBad.status === 400, `status=${createBad.status}`);

// Get single playlist
const plRes = await req('GET', `/api/playlists/${playlistId}`);
test(`GET /api/playlists/${playlistId} → 200`, plRes.status === 200, `name="${plRes.data.name}"`);
test('Playlist response has songs array', Array.isArray(plRes.data.songs), `songs=${plRes.data.songs?.length}`);

// Update playlist
const updatePL = await req('PUT', `/api/playlists/${playlistId}`, {
  name: `E2E Playlist Updated ${UNIQUE}`,
  description: 'Updated description'
});
test(`PUT /api/playlists/${playlistId} → 200`, updatePL.status === 200, `name="${updatePL.data.name}"`);
test('Playlist name updated', updatePL.data.name === `E2E Playlist Updated ${UNIQUE}`, `name="${updatePL.data.name}"`);

// Add song to playlist
const addSong = await req('POST', `/api/playlists/${playlistId}/songs`, { songId });
test(`POST /api/playlists/${playlistId}/songs → 200`, addSong.status === 200, `songId=${songId}`);
test('Playlist now contains the song', addSong.data.songs?.some(s => s.id === songId), `songs count=${addSong.data.songs?.length}`);

// Add same song again (should not duplicate)
const addDup = await req('POST', `/api/playlists/${playlistId}/songs`, { songId });
test('Adding duplicate song is idempotent', addDup.status === 200 && addDup.data.songs?.filter(s => s.id === songId).length === 1, 'no duplication');

// Remove song from playlist
const removeSong = await req('DELETE', `/api/playlists/${playlistId}/songs/${songId}`);
test(`DELETE /api/playlists/${playlistId}/songs/${songId} → 200`, removeSong.status === 200, `remaining=${removeSong.data.songs?.length}`);
test('Song removed from playlist', !removeSong.data.songs?.some(s => s.id === songId), 'song gone');

// 404 for missing playlist
const plNotFound = await req('GET', '/api/playlists/99999999');
test('GET /api/playlists/99999999 → 404', plNotFound.status === 404, `status=${plNotFound.status}`);

// Delete playlist
const delPL = await req('DELETE', `/api/playlists/${playlistId}`);
test(`DELETE /api/playlists/${playlistId} → 200`, delPL.status === 200, `success=${delPL.data.success}`);

// Verify playlist is gone
const goneRes = await req('GET', `/api/playlists/${playlistId}`);
test('Deleted playlist returns 404', goneRes.status === 404, `status=${goneRes.status}`);

// ═══════════════════════════════════════════════════
//  7. ALBUMS
// ═══════════════════════════════════════════════════
section('7. Albums');

const albumsRes = await req('GET', '/api/albums');
test('GET /api/albums → 200', albumsRes.status === 200, `count=${albumsRes.data.length}`);
test('Albums returns array', Array.isArray(albumsRes.data), `count=${albumsRes.data.length}`);

if (albumsRes.data.length > 0) {
  albumId = albumsRes.data[0].id;
  const albumRes = await req('GET', `/api/albums/${albumId}`);
  test(`GET /api/albums/${albumId} → 200`, albumRes.status === 200, `name="${albumRes.data.name}"`);
  test('Album has songs array', Array.isArray(albumRes.data.songs), `songs=${albumRes.data.songs?.length}`);
} else {
  test('GET /api/albums/:id (skipped — no albums in DB)', true, 'N/A');
  test('Album has songs array (skipped)', true, 'N/A');
}

const albNotFound = await req('GET', '/api/albums/99999999');
test('GET /api/albums/99999999 → 404', albNotFound.status === 404, `status=${albNotFound.status}`);

// ═══════════════════════════════════════════════════
//  8. ARTISTS
// ═══════════════════════════════════════════════════
section('8. Artists');

const artistsRes = await req('GET', '/api/artists');
test('GET /api/artists → 200', artistsRes.status === 200, `count=${artistsRes.data.length}`);
test('Artists returns array', Array.isArray(artistsRes.data), `count=${artistsRes.data.length}`);

if (artistsRes.data.length > 0) {
  artistId = artistsRes.data[0].id;
  const artistRes = await req('GET', `/api/artists/${artistId}`);
  test(`GET /api/artists/${artistId} → 200`, artistRes.status === 200, `name="${artistRes.data.name}"`);
  test('Artist has songs array', Array.isArray(artistRes.data.songs), `songs=${artistRes.data.songs?.length}`);
  test('Artist has albums array', Array.isArray(artistRes.data.albums), `albums=${artistRes.data.albums?.length}`);
} else {
  test('GET /api/artists/:id (skipped — no artists in DB)', true, 'N/A');
  test('Artist has songs array (skipped)', true, 'N/A');
  test('Artist has albums array (skipped)', true, 'N/A');
}

const artNotFound = await req('GET', '/api/artists/99999999');
test('GET /api/artists/99999999 → 404', artNotFound.status === 404, `status=${artNotFound.status}`);

// ═══════════════════════════════════════════════════
//  9. SEARCH
// ═══════════════════════════════════════════════════
section('9. Search');

const emptySearch = await req('GET', '/api/search?q=');
test('GET /api/search?q= (empty) → 200', emptySearch.status === 200, `status=${emptySearch.status}`);
test('Empty search returns empty arrays', 
  Array.isArray(emptySearch.data.songs) && emptySearch.data.songs.length === 0, 'all arrays empty');

const fullSearch = await req('GET', '/api/search?q=a');
test('GET /api/search?q=a → 200', fullSearch.status === 200, `status=${fullSearch.status}`);
test('Search response has songs key', Array.isArray(fullSearch.data.songs), `songs=${fullSearch.data.songs?.length}`);
test('Search response has playlists key', Array.isArray(fullSearch.data.playlists), `playlists=${fullSearch.data.playlists?.length}`);
test('Search response has albums key', Array.isArray(fullSearch.data.albums), `albums=${fullSearch.data.albums?.length}`);
test('Search response has artists key', Array.isArray(fullSearch.data.artists), `artists=${fullSearch.data.artists?.length}`);

if (songsRes.data.length > 0) {
  const exactWord = songsRes.data[0].artist.split(' ')[0];
  const artistSearch = await req('GET', `/api/search?q=${encodeURIComponent(exactWord)}`);
  test(`Search for artist "${exactWord.slice(0,15)}" finds songs`, artistSearch.data.songs?.length > 0, `hits=${artistSearch.data.songs?.length}`);
}

// ═══════════════════════════════════════════════════
//  10. EDGE CASES & VALIDATION
// ═══════════════════════════════════════════════════
section('10. Edge Cases & Validation');

// Register with missing fields
const regMissing = await req('POST', '/api/auth/register', { username: 'only_user' });
test('Register missing name+password → 400', regMissing.status === 400, `status=${regMissing.status}`);

// Login with missing fields
const loginMissing = await req('POST', '/api/auth/login', { username: 'only_user' });
test('Login missing password → 400', loginMissing.status === 400, `status=${loginMissing.status}`);

// ═══════════════════════════════════════════════════
//  SUMMARY
// ═══════════════════════════════════════════════════
const total = results.pass + results.fail;
const pct = ((results.pass / total) * 100).toFixed(1);

console.log(`\n${'═'.repeat(55)}`);
console.log(`  📊  TEST SUMMARY`);
console.log(`${'─'.repeat(55)}`);
console.log(`  Total   : ${total}`);
console.log(`  ✅ Pass  : ${results.pass}`);
console.log(`  ❌ Fail  : ${results.fail}`);
console.log(`  Score   : ${pct}%`);
console.log(`${'═'.repeat(55)}\n`);

if (results.fail > 0) {
  console.log('  🔴 FAILED TESTS:');
  results.tests.filter(t => !t.pass).forEach(t => {
    console.log(`    • ${t.label}${t.detail ? ' — ' + t.detail : ''}`);
  });
  console.log('');
}

process.exit(results.fail > 0 ? 1 : 0);
