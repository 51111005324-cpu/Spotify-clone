const puppeteer = require('puppeteer');
const delay = ms => new Promise(res => setTimeout(res, ms));

(async () => {
  const browser = await puppeteer.launch({ args: ['--no-sandbox', '--disable-setuid-sandbox'] });
  const page = await browser.newPage();
  
  page.on('console', msg => console.log('PAGE LOG:', msg.text()));
  page.on('pageerror', err => console.error('PAGE ERROR:', err.message));
  
  await page.goto('http://localhost:3000');
  await delay(2000);
  
  // Go to the first playlist in the sidebar
  console.log('Navigating to first playlist via sidebar');
  await page.evaluate(() => {
    const item = document.querySelector('.sidebar-playlist-item');
    if (item) item.click();
    else console.log('No playlist in sidebar');
  });
  
  await delay(2000);

  // Remove the first song
  console.log('Clicking Remove Song');
  page.once('dialog', async dialog => {
    console.log('Remove Dialog:', dialog.message());
    await dialog.accept();
  });
  
  await page.evaluate(() => {
    const btn = document.querySelector('button[title="Remove from Playlist"]');
    if(btn) btn.click();
    else console.log('Remove button NOT FOUND in playlist view');
  });

  await delay(2000);

  // Delete the playlist
  console.log('Clicking Delete Playlist');
  page.once('dialog', async dialog => {
    console.log('Delete Dialog:', dialog.message());
    await dialog.accept();
  });
  
  await page.evaluate(() => {
    const btn = document.querySelector('button[onclick^="deletePlaylist"]');
    if(btn) btn.click();
    else console.log('Delete button NOT FOUND');
  });

  await delay(2000);
  console.log('Done testing delete/remove.');
  await browser.close();
})();
