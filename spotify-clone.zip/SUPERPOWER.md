# 🦸 SUPERPOWER.md — Advanced Web Dev Cheatsheet
### For: Full-Stack Projects (Node.js + Express + HTML/CSS/JS)
### By: Your Spotify Clone Project Experience

This file contains advanced patterns, ready-to-paste code blocks, design recipes,
and pro tips that elevate a basic project to an impressive college submission.

---

## ⚡ SUPERPOWER 1 — Instant Backend Boilerplate

Paste this into any new `server.js` and fill in the blanks:

```js
const express = require('express');
const cors    = require('cors');
const path    = require('path');
const app     = express();
const PORT    = 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../frontend')));

/* ── DATA ─────────────────────────────── */
// Replace with your actual data
const items = [
  { id: 1, name: 'Item One', description: 'First item', createdAt: new Date() },
  { id: 2, name: 'Item Two', description: 'Second item', createdAt: new Date() },
];
const users = [
  { id: 1, username: 'demo', password: 'demo123', name: 'Demo User', role: 'user' }
];

/* ── AUTH ─────────────────────────────── */
app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body;
  const user = users.find(u => u.username === username && u.password === password);
  if (!user) return res.status(401).json({ error: 'Invalid credentials' });
  const { password: _, ...safe } = user;
  res.json({ token: `tok-${user.id}-${Date.now()}`, user: safe });
});
app.post('/api/auth/register', (req, res) => {
  const { username, password, name, email } = req.body;
  if (!username || !password) return res.status(400).json({ error: 'Fields required' });
  if (users.find(u => u.username === username)) return res.status(409).json({ error: 'Username taken' });
  const u = { id: users.length + 1, username, password, name: name || username, email, role: 'user' };
  users.push(u);
  const { password: _, ...safe } = u;
  res.json({ token: `tok-${u.id}-${Date.now()}`, user: safe });
});

/* ── CRUD ─────────────────────────────── */
app.get   ('/api/items',     (req, res) => {
  const { q } = req.query;
  let r = items;
  if (q) r = r.filter(i => i.name.toLowerCase().includes(q.toLowerCase()));
  res.json(r);
});
app.get   ('/api/items/:id', (req, res) => {
  const i = items.find(i => i.id === +req.params.id);
  i ? res.json(i) : res.status(404).json({ error: 'Not found' });
});
app.post  ('/api/items',     (req, res) => {
  const n = { id: items.length + 1, ...req.body, createdAt: new Date() };
  items.push(n); res.json(n);
});
app.put   ('/api/items/:id', (req, res) => {
  const idx = items.findIndex(i => i.id === +req.params.id);
  if (idx < 0) return res.status(404).json({ error: 'Not found' });
  items[idx] = { ...items[idx], ...req.body }; res.json(items[idx]);
});
app.delete('/api/items/:id', (req, res) => {
  const idx = items.findIndex(i => i.id === +req.params.id);
  if (idx < 0) return res.status(404).json({ error: 'Not found' });
  items.splice(idx, 1); res.json({ success: true });
});

/* ── SEARCH ───────────────────────────── */
app.get('/api/search', (req, res) => {
  const q = (req.query.q || '').toLowerCase();
  if (!q) return res.json({ items: [] });
  res.json({ items: items.filter(i => i.name.toLowerCase().includes(q)) });
});

/* ── SERVE FRONTEND ───────────────────── */
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

app.listen(PORT, () => console.log(`\n🚀 Running at http://localhost:${PORT}\n`));
```

---

## ⚡ SUPERPOWER 2 — Instant Frontend Boilerplate

Paste into `app.js` — just fill in your resource name:

```js
const API = window.location.origin + '/api';

// ── STATE ──────────────────────────────────────────────
let state = {
  user: null, token: null,
  items: [],
  currentItem: null,
  searchTimer: null,
};

// ── API HELPER ─────────────────────────────────────────
async function api(path, opts = {}) {
  try {
    const res = await fetch(API + path, {
      headers: { 'Content-Type': 'application/json',
        ...(state.token ? { Authorization: `Bearer ${state.token}` } : {}) },
      ...opts,
    });
    if (!res.ok) throw await res.json();
    return res.json();
  } catch(e) {
    if (e.error) throw e;
    throw { error: 'Cannot connect. Is the server running?' };
  }
}

// ── TOAST ──────────────────────────────────────────────
function showToast(msg, icon = '✓') {
  const c = document.getElementById('toastContainer');
  if (!c) return;
  const t = document.createElement('div');
  t.className = 'toast';
  t.innerHTML = `<span>${icon}</span> ${msg}`;
  c.appendChild(t);
  setTimeout(() => { t.style.opacity = '0'; setTimeout(() => t.remove(), 400); }, 2500);
}

// ── AUTH ───────────────────────────────────────────────
async function login() {
  const username = document.getElementById('loginUsername').value.trim();
  const password = document.getElementById('loginPassword').value;
  const err = document.getElementById('loginError');
  const btn = document.querySelector('#loginScreen .btn-primary');
  err.classList.add('hidden');
  if (!username || !password) { err.textContent = 'Fill in all fields'; err.classList.remove('hidden'); return; }
  btn.textContent = 'Logging in…'; btn.disabled = true;
  try {
    const data = await api('/auth/login', { method:'POST', body: JSON.stringify({ username, password }) });
    saveSession(data); initApp();
  } catch(e) { err.textContent = e.error || 'Login failed'; err.classList.remove('hidden'); }
  finally { btn.textContent = 'Log In'; btn.disabled = false; }
}

async function register() {
  const name     = document.getElementById('regName').value.trim();
  const username = document.getElementById('regUsername').value.trim();
  const email    = document.getElementById('regEmail').value.trim();
  const password = document.getElementById('regPassword').value;
  const err = document.getElementById('registerError');
  const btn = document.querySelector('#registerScreen .btn-primary');
  err.classList.add('hidden');
  if (!name || !username || !password) { err.textContent = 'Fill in all fields'; err.classList.remove('hidden'); return; }
  btn.textContent = 'Creating…'; btn.disabled = true;
  try {
    const data = await api('/auth/register', { method:'POST', body: JSON.stringify({ name, username, email, password }) });
    saveSession(data); initApp();
  } catch(e) { err.textContent = e.error || 'Registration failed'; err.classList.remove('hidden'); }
  finally { btn.textContent = 'Sign Up'; btn.disabled = false; }
}

function saveSession({ token, user }) {
  state.token = token; state.user = user;
  localStorage.setItem('app_token', token);
  localStorage.setItem('app_user', JSON.stringify(user));
}
function logout() {
  localStorage.removeItem('app_token'); localStorage.removeItem('app_user');
  state.user = null; state.token = null;
  document.getElementById('app').classList.add('hidden');
  document.getElementById('loginScreen').classList.remove('hidden');
}
function showLogin()    { document.getElementById('registerScreen').classList.add('hidden'); document.getElementById('loginScreen').classList.remove('hidden'); }
function showRegister() { document.getElementById('loginScreen').classList.add('hidden'); document.getElementById('registerScreen').classList.remove('hidden'); }

// ── INIT ───────────────────────────────────────────────
async function initApp() {
  document.getElementById('loginScreen')?.classList.add('hidden');
  document.getElementById('registerScreen')?.classList.add('hidden');
  document.getElementById('app').classList.remove('hidden');
  if (document.getElementById('userName')) document.getElementById('userName').textContent = state.user.name;
  if (document.getElementById('userAvatar')) document.getElementById('userAvatar').textContent = state.user.name[0].toUpperCase();
  try {
    state.items = await api('/items');
    renderItems(state.items);
    navigate('home');
  } catch(e) { console.error(e); }
}

window.addEventListener('DOMContentLoaded', () => {
  const token = localStorage.getItem('app_token');
  const user  = localStorage.getItem('app_user');
  if (token && user) { state.token = token; state.user = JSON.parse(user); initApp(); }
  // Enter key on login
  document.getElementById('loginPassword')?.addEventListener('keydown', e => { if(e.key==='Enter') login(); });
  document.getElementById('loginUsername')?.addEventListener('keydown', e => { if(e.key==='Enter') login(); });
});

// ── NAVIGATION ─────────────────────────────────────────
function navigate(view, id = null) {
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  const el = document.getElementById(view + 'View');
  if (el) el.classList.add('active');
}

// ── RENDER ─────────────────────────────────────────────
function renderItems(items) {
  const grid = document.getElementById('itemsGrid');
  if (!grid) return;
  if (!items.length) { grid.innerHTML = '<div class="empty-state">No items found.</div>'; return; }
  grid.innerHTML = items.map(i => itemCard(i)).join('');
}
function itemCard(i) {
  return `<div class="card" onclick="viewItem(${i.id})">
    <div class="card-title">${i.name}</div>
    <div class="card-sub">${i.description || ''}</div>
  </div>`;
}

// ── SEARCH ─────────────────────────────────────────────
function debounceSearch(val) {
  clearTimeout(state.searchTimer);
  state.searchTimer = setTimeout(async () => {
    const results = val.trim() ? await api(`/search?q=${encodeURIComponent(val)}`) : { items: state.items };
    renderItems(results.items);
  }, 300);
}

// ── CREATE ─────────────────────────────────────────────
async function createItem() {
  const name = prompt('Item name:');
  if (!name?.trim()) return;
  const item = await api('/items', { method:'POST', body: JSON.stringify({ name }) });
  state.items.push(item);
  renderItems(state.items);
  showToast(`"${item.name}" created`, '🎉');
}

// ── DELETE ─────────────────────────────────────────────
async function deleteItem(id) {
  if (!confirm('Delete this item?')) return;
  await api(`/items/${id}`, { method:'DELETE' });
  state.items = state.items.filter(i => i.id !== id);
  renderItems(state.items);
  showToast('Item deleted', '🗑️');
}

// ── UTILS ──────────────────────────────────────────────
function formatDate(d) {
  return new Date(d).toLocaleDateString('en-IN', { day:'numeric', month:'short', year:'numeric' });
}
function formatPrice(n) { return '₹' + Number(n).toLocaleString('en-IN'); }
function formatDuration(sec) {
  const m = Math.floor(sec/60), s = String(sec%60).padStart(2,'0');
  return `${m}:${s}`;
}

// ── KEYBOARD SHORTCUTS ─────────────────────────────────
document.addEventListener('keydown', e => {
  if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
  if (e.code === 'Escape') navigate('home');
});
```

---

## ⚡ SUPERPOWER 3 — CSS Theme Recipes

### 🎵 Dark Music Theme (like Spotify)
```css
:root {
  --bg: #121212; --bg2: #181818; --bg3: #242424;
  --accent: #1ed760; --accent-glow: rgba(30,215,96,0.25);
  --text: #fff; --text2: #b3b3b3; --text3: #535353;
  --radius: 10px;
}
body { background: var(--bg); color: var(--text); font-family: 'Outfit', sans-serif; }
```

### 🛍️ Light E-Commerce Theme
```css
:root {
  --bg: #f8f9fa; --bg2: #ffffff; --bg3: #f0f0f0;
  --accent: #ff6b35; --accent-glow: rgba(255,107,53,0.2);
  --text: #1a1a1a; --text2: #666; --text3: #999;
  --radius: 12px;
}
body { background: var(--bg); color: var(--text); font-family: 'Poppins', sans-serif; }
```

### 📱 Social Media Theme (Purple)
```css
:root {
  --bg: #fafafa; --bg2: #ffffff; --bg3: #f0f0f0;
  --accent: #8b5cf6; --accent-glow: rgba(139,92,246,0.2);
  --text: #111; --text2: #666; --text3: #999;
  --radius: 16px;
}
```

### 📊 Dashboard Theme (Dark Blue)
```css
:root {
  --bg: #0f172a; --bg2: #1e293b; --bg3: #334155;
  --accent: #38bdf8; --accent-glow: rgba(56,189,248,0.2);
  --text: #f1f5f9; --text2: #94a3b8; --text3: #475569;
  --radius: 8px;
}
```

### 🍕 Food / Restaurant Theme
```css
:root {
  --bg: #fff8f3; --bg2: #ffffff; --bg3: #fef3e2;
  --accent: #ef4444; --accent-glow: rgba(239,68,68,0.15);
  --text: #1c1917; --text2: #78716c; --text3: #a8a29e;
  --radius: 14px;
}
```

---

## ⚡ SUPERPOWER 4 — Animation Library

### Card Hover (copy-paste ready):
```css
.card {
  transition: transform 0.25s cubic-bezier(0.34,1.56,0.64,1),
              box-shadow 0.2s ease,
              background 0.2s ease;
}
.card:hover {
  transform: translateY(-6px) scale(1.02);
  box-shadow: 0 20px 48px rgba(0,0,0,0.2);
}
```

### Button Bounce:
```css
.btn {
  transition: transform 0.2s cubic-bezier(0.34,1.56,0.64,1), background 0.2s;
}
.btn:hover  { transform: scale(1.05); }
.btn:active { transform: scale(0.96); }
```

### Fade-in View:
```css
.view { display: none; }
.view.active {
  display: block;
  animation: fadeInUp 0.3s ease;
}
@keyframes fadeInUp {
  from { opacity:0; transform:translateY(12px); }
  to   { opacity:1; transform:translateY(0); }
}
```

### Heart Pop (like button):
```css
.liked { color: #ef4444 !important; }
.pop   { animation: heartPop 0.35s cubic-bezier(0.34,1.56,0.64,1); }
@keyframes heartPop {
  0%   { transform: scale(1); }
  40%  { transform: scale(1.6); }
  70%  { transform: scale(0.9); }
  100% { transform: scale(1); }
}
```

### Staggered card reveal:
```css
.card { animation: cardIn 0.4s ease backwards; }
.card:nth-child(1){animation-delay:.05s}
.card:nth-child(2){animation-delay:.10s}
.card:nth-child(3){animation-delay:.15s}
.card:nth-child(4){animation-delay:.20s}
.card:nth-child(5){animation-delay:.25s}
@keyframes cardIn {
  from { opacity:0; transform:translateY(20px); }
  to   { opacity:1; transform:translateY(0); }
}
```

### Shimmer loading skeleton:
```css
.skeleton {
  background: linear-gradient(90deg, #2a2a2a 25%, #3a3a3a 50%, #2a2a2a 75%);
  background-size: 200% 100%;
  animation: skeleton 1.5s infinite;
  border-radius: 6px; height: 16px;
}
@keyframes skeleton { 0%{background-position:200%} 100%{background-position:-200%} }
```

### Shake (for form errors):
```css
@keyframes shake {
  0%,100%{transform:translateX(0)}
  25%{transform:translateX(-8px)}
  75%{transform:translateX(8px)}
}
.error { animation: shake 0.3s ease; }
```

---

## ⚡ SUPERPOWER 5 — Common UI Components

### Toast Notification (HTML + CSS + JS):
```html
<div id="toastContainer" style="
  position:fixed; bottom:20px; left:50%; transform:translateX(-50%);
  z-index:9999; display:flex; flex-direction:column; gap:8px; pointer-events:none;">
</div>
```
```css
.toast {
  background: #242424; border: 1px solid #333; border-radius: 50px;
  padding: 10px 22px; font-size: 13px; font-weight: 500; color: #fff;
  display: flex; align-items: center; gap: 8px;
  box-shadow: 0 8px 32px rgba(0,0,0,0.5);
  animation: toastIn 0.35s cubic-bezier(0.34,1.56,0.64,1);
  transition: opacity 0.3s;
}
@keyframes toastIn { from{opacity:0;transform:translateY(16px)} to{opacity:1;transform:translateY(0)} }
```

### Modal / Popup:
```html
<div id="modal" class="modal-overlay hidden" onclick="closeModal(event)">
  <div class="modal-box">
    <button class="modal-close" onclick="closeModal()">✕</button>
    <div id="modalContent"></div>
  </div>
</div>
```
```css
.modal-overlay {
  position:fixed; inset:0; z-index:500;
  background:rgba(0,0,0,0.7); backdrop-filter:blur(4px);
  display:flex; align-items:center; justify-content:center;
  animation: fadeIn 0.2s ease;
}
.modal-box {
  background:#1e1e1e; border:1px solid #333; border-radius:16px;
  padding:32px; max-width:480px; width:90%;
  position:relative; animation: slideUp 0.3s cubic-bezier(0.34,1.56,0.64,1);
}
.modal-close { position:absolute; top:16px; right:16px; font-size:18px; color:#666; }
```
```js
function openModal(content) {
  document.getElementById('modalContent').innerHTML = content;
  document.getElementById('modal').classList.remove('hidden');
}
function closeModal(e) {
  if (!e || e.target === document.getElementById('modal'))
    document.getElementById('modal').classList.add('hidden');
}
```

### Confirmation Dialog:
```js
function confirm(message, onYes) {
  openModal(`
    <h3 style="margin-bottom:16px">${message}</h3>
    <div style="display:flex;gap:12px">
      <button class="btn btn-danger" onclick="(${onYes.toString()})();closeModal()">Yes, delete</button>
      <button class="btn btn-outline" onclick="closeModal()">Cancel</button>
    </div>`);
}
```

### Search Bar with Suggestions:
```html
<div class="search-wrap" style="position:relative">
  <input id="searchInput" class="search-input"
    placeholder="Search..."
    oninput="debounceSearch(this.value)"
    onblur="setTimeout(()=>document.getElementById('suggestions').style.display='none',200)" />
  <div id="suggestions" class="suggestions-box" style="display:none"></div>
</div>
```
```css
.suggestions-box {
  position:absolute; top:calc(100%+8px); left:0; right:0;
  background:#242424; border:1px solid #333; border-radius:12px;
  overflow:hidden; box-shadow:0 16px 48px rgba(0,0,0,0.5); z-index:100;
}
.suggestion-item { padding:10px 16px; cursor:pointer; font-size:13px; }
.suggestion-item:hover { background:#2a2a2a; }
```

### Star Rating:
```html
<div class="star-rating" id="stars">
  <span onclick="rate(1)">★</span><span onclick="rate(2)">★</span>
  <span onclick="rate(3)">★</span><span onclick="rate(4)">★</span>
  <span onclick="rate(5)">★</span>
</div>
```
```css
.star-rating span { font-size:24px; color:#333; cursor:pointer; transition:color 0.15s; }
.star-rating span.active, .star-rating span:hover { color:#f59e0b; }
```
```js
let currentRating = 0;
function rate(n) {
  currentRating = n;
  document.querySelectorAll('.star-rating span').forEach((s,i) => {
    s.classList.toggle('active', i < n);
  });
}
```

---

## ⚡ SUPERPOWER 6 — Database Upgrade Path

When the teacher asks "where is the database?" — use this answer:

> "Currently using in-memory arrays for demo. To upgrade to a real database, replace the arrays with MongoDB using Mongoose."

### Quick MongoDB upgrade (just replace data arrays):
```js
// Install: npm install mongoose
const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost:27017/appname');

const ItemSchema = new mongoose.Schema({
  name: String, description: String, createdAt: { type: Date, default: Date.now }
});
const Item = mongoose.model('Item', ItemSchema);

// Replace: const items = [...] with mongoose queries:
app.get('/api/items', async (req, res) => {
  const items = await Item.find();
  res.json(items);
});
app.post('/api/items', async (req, res) => {
  const item = await Item.create(req.body);
  res.json(item);
});
```

---

## ⚡ SUPERPOWER 7 — Debugging Cheatsheet

### Port already in use:
```bash
kill -9 $(lsof -t -i:3000)   # Mac/Linux
netstat -ano | findstr :3000   # Windows (find PID, then:)
taskkill /PID <PID> /F         # Windows kill
```

### Check if server is running:
```bash
curl http://localhost:3000/api/items
# Should return JSON data
```

### Common errors and fixes:

| Error | Cause | Fix |
|-------|-------|-----|
| `Cannot GET /api/items` | Route not defined | Check route spelling in server.js |
| `CORS error` | Missing cors() | Add `app.use(cors())` at top |
| `Cannot connect to server` | Server not running | Run `npm start` in backend/ |
| `ENOENT index.html` | Wrong path | Check `__dirname` path in server.js |
| `SyntaxError` | Bad JSON | Use `JSON.parse` safely with try/catch |
| `404 on login` | Opening file directly | Go to `http://localhost:3000` |
| `password shown in response` | Missing destructure | Use `const { password: _, ...safe } = user` |

---

## ⚡ SUPERPOWER 8 — Presentation Tips

When presenting your college project, mention these:

### Architecture Decisions (sound smart):
- "We used a **RESTful API** design with proper HTTP methods and status codes"
- "The frontend uses a **single state object** pattern for predictable data flow"
- "We implemented **session persistence** using localStorage to improve UX"
- "The backend uses **in-memory storage** for demo, with a clear upgrade path to MongoDB"
- "We added **debounced search** to reduce unnecessary API calls"
- "The UI is **fully responsive** using CSS Grid and Flexbox"

### Features to highlight:
- ✅ Login / Register with validation
- ✅ Session persistence (stays logged in on refresh)
- ✅ Real-time search with debounce
- ✅ Toast notifications for all actions
- ✅ Loading states on all async operations
- ✅ Error handling on every API call
- ✅ Keyboard shortcuts for power users
- ✅ Mobile responsive design

### Upgrade path to mention:
1. Replace in-memory arrays → **MongoDB Atlas**
2. Replace fake tokens → **JWT (jsonwebtoken)**
3. Add image uploads → **Multer + Cloudinary**
4. Add real-time features → **Socket.io**
5. Deploy to the internet → **Railway / Render / Vercel**

---

## ⚡ SUPERPOWER 9 — One-Page Quick Reference

```
BACKEND                          FRONTEND
───────────────────────────────  ───────────────────────────────
npm init -y                      Fonts: Outfit / DM Sans / Poppins
npm install express cors         Always: CSS variables (:root)
node server.js (start)           Always: window.location.origin + '/api'
Ctrl+C (stop)                    Always: localStorage for session
kill -9 $(lsof -t -i:3000)       Always: btn.disabled during async
                                 Always: try/catch on every fetch()
ROUTES                           Always: Enter key on password field
GET    → read data               Always: debounce on search input
POST   → create data
PUT    → update data             PATTERNS
DELETE → remove data             state object → single source of truth
                                 navigate(view) → show/hide .view divs
STATUS CODES                     showToast(msg) → user feedback
200 → success                    renderX(data) → DOM from data
201 → created                    api(path, opts) → fetch wrapper
400 → bad request
401 → unauthorized               CSS CLASSES
404 → not found                  .card .card-title .card-sub
409 → conflict (duplicate)       .btn-primary .btn-outline
500 → server error               .hidden (display:none !important)
                                 .view .view.active
DEMO ACCOUNT                     .nav-item .nav-item.active
username: demo                   .toast #toastContainer
password: demo123
```

---

*Made from real project experience — Spotify Clone, College Full-Stack Project*
*Stack: Node.js + Express + Vanilla HTML/CSS/JS*
