(async () => {
  try {
    console.log('Creating playlist...');
    let res = await fetch('http://localhost:3000/api/playlists', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: 'E2E API Test' })
    });
    let pl = await res.json();
    console.log('Playlist created:', pl);

    console.log('Adding song 1 to playlist...');
    res = await fetch(`http://localhost:3000/api/playlists/${pl.id}/songs`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ songId: 1 })
    });
    let updatedPl = await res.json();
    console.log('Song added. Playlist songs length:', updatedPl.songs.length);

    console.log('Fetching playlist...');
    res = await fetch(`http://localhost:3000/api/playlists/${pl.id}`);
    let fetchedPl = await res.json();
    console.log('Fetched songs length:', fetchedPl.songs.length);
    if(fetchedPl.songs.length === 0) {
      console.error('ERROR: Song was not added!');
      process.exit(1);
    }

    console.log('Removing song from playlist...');
    res = await fetch(`http://localhost:3000/api/playlists/${pl.id}/songs/1`, {
      method: 'DELETE'
    });
    let deleteRes = await res.json();
    console.log('Delete res:', deleteRes);

    console.log('Deleting playlist...');
    res = await fetch(`http://localhost:3000/api/playlists/${pl.id}`, {
      method: 'DELETE'
    });
    let deletePlRes = await res.json();
    console.log('Delete PL res:', deletePlRes);

    console.log('All tests passed!');
  } catch (e) {
    console.error(e);
  }
})();
